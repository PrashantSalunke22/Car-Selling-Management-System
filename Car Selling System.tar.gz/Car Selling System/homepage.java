import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
class homepage extends JFrame implements ActionListener
{
    JButton bsale,bpurchase,bexit,bcustform,bpaymntinfo,bcarinfo,bbill,breprt;
    JLabel l1,l2,l3;
	JPanel p1,p2,p3,p4,p5;
	ImageIcon ic=new ImageIcon("supercar3.jpg");
    Container cp;
    Font f1,f2,f3;
	homepage()  //constr
	{
        super("Home Page");
        cp=getContentPane();
        cp.setLayout(new BorderLayout());
        try
        {
        	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex)
        {
        	System.out.println(ex);
        }
        f1=new Font("Times New Roman",Font.BOLD,20);
        f2=new Font("Times New Roman",Font.BOLD,45);
        f3=new Font("Times New Roman",Font.BOLD,15);
               
        l1=new JLabel("SHAAN CARS Pvt. Ltd.");
		l1.setFont(f2);
		l1.setForeground(Color.red);
              
        bcarinfo=new JButton("Car_Info");
        bcarinfo.setFont(f1);
        bcarinfo.setBounds(20,400,500,25); 
        bcarinfo.addActionListener(this);
        bcarinfo.setToolTipText("SEE YOUR CARS INFORMATION");
               
        bcustform=new JButton("Cust_Form");
        bcustform.setFont(f1);
        bcustform.setBounds(20,450,500,25); 
        bcustform.addActionListener(this);
        bcustform.setToolTipText("FILL CUSTOMER INFORMATION");
              
        bpaymntinfo=new JButton("PaymentInfo");
        bpaymntinfo.setFont(f1);
        bpaymntinfo.setBounds(20,500,500,25); 
        bpaymntinfo.addActionListener(this);
        bpaymntinfo.setToolTipText("SEE PAYMENT INFORMATION");
             
        bbill=new JButton("Bill");
        bbill.setFont(f1);
        bbill.setBounds(20,550,500,25); 
        bbill.addActionListener(this);
        bbill.setToolTipText("GENERATES BILL");
              
        bsale=new JButton("Sale");
        bsale.setFont(f1);
        bsale.setBounds(20,600,500,25); 
        bsale.addActionListener(this);
        bsale.setToolTipText("SALE INFORMATION");
              
        bpurchase=new JButton("Stock");
        bpurchase.setFont(f1);
        bpurchase.setBounds(20,650,500,25); 
        bpurchase.addActionListener(this);
        bpurchase.setToolTipText("SEE YOUR PURCHASE INFORMATION");

		breprt=new JButton("Reports");
        breprt.setFont(f1);
        breprt.setBounds(20,700,500,25); 
        breprt.addActionListener(this);
        breprt.setToolTipText("Show Reports");
              
        bexit=new JButton("Exit");
        bexit.setFont(f1);
        bexit.setBounds(20,750,500,25); 
        bexit.addActionListener(this);
	    bexit.setToolTipText("EXIT FROM SYSTEM");
                
     	l2=new JLabel("� 2010_2011 Vin All rights reserved.");
        l2.setBounds(20,475,500,25); 
        l2.setFont(f3);
        l2.setForeground(Color.blue);

   		l3=new JLabel("",ic,JLabel.RIGHT);
		l3.setSize(700,450);
		
   		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
            		
		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
        
        p3=new JPanel();
	    p3.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
	
		p4=new JPanel();
	    p4.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
	
		p5=new JPanel();
	    p5.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
	
		p1.setLayout(new FlowLayout());
        p2.setLayout(new FlowLayout());
        p3.setLayout(new FlowLayout());
        p4.setLayout(new GridLayout(4,1));
        p5.setLayout(new GridLayout(4,1));
                
        p1.add(l1);
                
       	p2.add(l3);

        p4.add(bcustform);
        p4.add(bbill);
        p4.add(bsale); 
        p4.add(bexit);

        p5.add(bcarinfo);		
      	p5.add(bpaymntinfo);
      	p5.add(bpurchase);
      	p5.add(breprt);
      	
        p3.add(l2); 
        
      	add(p1,BorderLayout.NORTH);
        add(p3,BorderLayout.SOUTH);
        add(p4,BorderLayout.EAST);
        add(p2,BorderLayout.CENTER);
        add(p5,BorderLayout.WEST);      
        
        
        setBounds(190,100,650,550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
    } //end of constr
	public void actionPerformed(ActionEvent ae)
	{
        if(ae.getSource()==bexit)
        {
	        int r=JOptionPane.showConfirmDialog(null,"Do You Want To Exit ?","THANK YOU",JOptionPane.YES_NO_OPTION);
			if(r==JOptionPane.YES_OPTION)
        	System.exit(0);
        }
        if(ae.getSource()==bcarinfo)
        {
            dispose();
        	carinfo1 bi=new carinfo1(); 
        }
        if(ae.getSource()==bcustform)
        {
            dispose();
        	custinfo ci=new custinfo();
        }
        if(ae.getSource()==bpaymntinfo)
        {
            dispose();
        	payinfo pi=new payinfo(); 
        }
        if(ae.getSource()==bbill)
        {
            dispose();
        	billinfo bi=new billinfo();
        }
        if(ae.getSource()==bsale)
        {
            dispose();
        	cust_sale_info si=new cust_sale_info();
        }
        if(ae.getSource()==  bpurchase)
        {
            dispose();
        	qtyinfo qty=new qtyinfo();
        }
        if(ae.getSource()== breprt)
        {
            dispose();
        	report rp=new report();
    	}
	}
	public static void main(String args[])
    {
       homepage hp = new homepage();
    }
}