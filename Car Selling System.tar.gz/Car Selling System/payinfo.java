import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.io.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class payinfo extends JFrame implements ActionListener
{

	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	JButton b1,b2,b3,b4,b5,b6,b7; 
	Container cp;
	JPanel p1,p2,p3;
	JComboBox pay = new JComboBox();
    JComboBox work = new JComboBox();
	Font f1,f2,f3;
	int updateenqno = 0;
    int custNo;
    String cname ,addperm,addtemp,phno,phlan;
    ResultSet rs1;
    Statement s1;
    Connection con;
	payinfo()
	{
		super("Payment Information Form");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		try
        {
        	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    con = DriverManager.getConnection("jdbc:odbc:tybsc1");
	   	    s1=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs1 = s1.executeQuery("select * from custinfo");
            while(rs1.next())
            {
            	custNo =rs1.getInt(1);
				cname =rs1.getString(2);
				addtemp =rs1.getString(5);
				addperm=rs1.getString(6);
				phno =rs1.getString(7);
				phlan =rs1.getString(8);
            }
		}
        catch(Exception e)
		{
			 System.out.println(e);
        }  
		f1=new Font("Times New Roman",Font.BOLD,15);
        f2=new Font("Times New Roman",Font.BOLD,45);
        f3=new Font("Times New Roman",Font.BOLD,10);
		
        l1=new JLabel(" SHAAN CARS Pvt. Ltd. ");
		l1.setFont(f2);
        l1.setForeground(Color.red);
		
        l2=new JLabel(" 1:\t PAYMENT ");
		l2.setFont(f1);
        l2.setForeground(Color.black);
		
		l3=new JLabel(" 2:\t CUSTOMER NUMBER");
		l3.setFont(f1);
        l3.setForeground(Color.black);

		t1=new JTextField(5);
		t1.setFont(f1);
        t1.setForeground(Color.black);
	 	t1.setText(String.valueOf(custNo)); 
		t1.setEditable(false);
		
		l4=new JLabel(" 3:\t CUSTOMER NAME");
		l4.setFont(f1);
        l4.setForeground(Color.black);
		
		t2=new JTextField(5);
		t2.setFont(f1);
        t2.setForeground(Color.black);
        t2.setText(String.valueOf(cname)); 

		l5=new JLabel(" 4:\t ADDRESS (TEMP)");
		l5.setFont(f1);
        l5.setForeground(Color.black);
		
		t3=new JTextField(5);		
		t3.setFont(f1);
        t3.setForeground(Color.black);
        t3.setText(String.valueOf(addtemp)); 

		l6=new JLabel(" 5:\t ADDRESS (PERM)");
		l6.setFont(f1);
        l6.setForeground(Color.black);
		
		t4=new JTextField(5);
		t4.setFont(f1);
        t4.setForeground(Color.black);
        t4.setText(String.valueOf(addperm)); 

		l7=new JLabel(" 6:\t PHONE NO.(Mob.)");
		l7.setFont(f1);
        l7.setForeground(Color.black);
		
		t5=new JTextField(5);
		t5.setFont(f1);
        t5.setForeground(Color.black);
        t5.setText(String.valueOf(phno));

	   	l8=new JLabel(" 7:\t PHONE NO.(Lan.)");
		l8.setFont(f1);
        l8.setForeground(Color.black);
		        
		t6=new JTextField(5);
		t6.setFont(f1);
        t6.setForeground(Color.black);
		t6.setText(String.valueOf(phlan)); 
        
        l9=new JLabel(" 8:\t WORKING ");
		l9.setFont(f1);
        l9.setForeground(Color.black);
		
        l10=new JLabel(" 9:\t SPECIFY ");
		l10.setFont(f1);
        l10.setForeground(Color.black);
		
		t7=new JTextField(5);
		t7.setFont(f1);
        t7.setForeground(Color.black);
        
        l11=new JLabel(" 10:\t MONTHLY INCOME ");
		l11.setFont(f1);
        l11.setForeground(Color.black);
		
		t8=new JTextField(5);
		t8.setFont(f1);
        t8.setForeground(Color.black);
        
        l12=new JLabel(" 11:\t Ex-Showroom Price With LBT ");
		l12.setFont(f1);
        l12.setForeground(Color.black);
		
		t9=new JTextField(5);
		t9.setFont(f1);
        t9.setForeground(Color.black);

        l13=new JLabel(" 13:\t Ex-Showroom Price Without LBT ");
		l13.setFont(f1);
        l13.setForeground(Color.black);
       
        t10=new JTextField(5);
		t10.setFont(f1);
        t10.setForeground(Color.black);

		b1=new JButton("HOME");
		b1.setFont(f1);
		b1.addActionListener(this);
		
		b2=new JButton("BACK");
		b2.setFont(f1);
		b2.addActionListener(this);
		
		b3=new JButton("CLEAR");
		b3.setFont(f1);
		b3.addActionListener(this);
		
		b4=new JButton("SAVE");
		b4.setFont(f1);
		b4.addActionListener(this);
		
		b5=new JButton("UPDATE");
		b5.setFont(f1);
		b5.addActionListener(this);
		
		b6=new JButton("NEXT");
		b6.setFont(f1);
		b6.addActionListener(this);

		b7=new JButton("SEARCH");
		b7.setFont(f1);
		b7.addActionListener(this);

		pay.addItem("CASH");
        pay.addItem("CHEQUE");
        
		work.addItem(" *  COMPANY");
        work.addItem(" *  BUISNESS");
        work.addItem(" *  ORGANISATION");
        
		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p3=new JPanel();
		p3.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
			
		p1.setLayout(new FlowLayout());
        p2.setLayout(new GridLayout(15,2));
        p3.setLayout(new FlowLayout());
        
        p1.add(l1);
      	
      	p2.add(l2);		
		p2.add(pay);
 		
		p2.add(l3);		
		p2.add(t1); 
		
		p2.add(l4);		
		p2.add(t2); 
		
		p2.add(l5);		
		p2.add(t3);
		
		p2.add(l6);		
		p2.add(t4);
		
		p2.add(l7);
		p2.add(t5);
		
		p2.add(l8);
		p2.add(t6);
		
		p2.add(l9);
		p2.add(work);
		
		p2.add(l10);
		p2.add(t7);
		
		p2.add(l11);
		p2.add(t8);
		
		p2.add(l12);
		p2.add(t9);
		
		p2.add(l13);
		p2.add(t10);
		
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		p3.add(b5);
		p3.add(b6);
		p3.add(b7);
		
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p2,BorderLayout.CENTER);
		cp.add(p3,BorderLayout.SOUTH);
		
		setBounds(130,100,800,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void do_update()
	{
		Connection con;
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from payinfo");
			while(rs.next())
			{
				updateenqno = rs.getInt(1);				
			}
			updateenqno = updateenqno +1;
	    }
	    catch (SQLException se) 
	    {
	    	System.out.println ("Ex1:"+se);
	    }
	    catch (Exception eg) 
	    {
	    	System.out.println ("Ex2:"+eg);
	    }
	}
	public void actionPerformed(ActionEvent ae)	
	{
		String str = ae.getActionCommand();
	    Connection con ;
	    Statement stat ;
		if(ae.getSource()==b1)
		{
			dispose();
			homepage hp=new homepage();
		}
		if(ae.getSource()==b2)
		{
		 	dispose();
		 	custinfo bi=new custinfo();
		}
		if(ae.getSource()==b3)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
 			t6.setText("");
			t7.setText("");
			t8.setText("");
			t9.setText("");
			t10.setText("");
		}
		if(ae.getSource()==b4)
		{
			Pattern pattern = Pattern.compile("\\d{3}-\\d{7}");
			Pattern p1 = Pattern.compile("^[A-Za-z]+$");
			Pattern p2 = Pattern.compile("^[A-Za-z]+$");
			Pattern p3 = Pattern.compile("^[A-Za-z]+$");
			Pattern p4 = Pattern.compile("^[A-Za-z]+$");
			Pattern p5 = Pattern.compile("^[A-Za-z]+$");
			Pattern p6 = Pattern.compile("^[A-Za-z]+$");
       		Matcher matcher = pattern.matcher(t6.getText());
			Matcher matcher1 = p1.matcher(t5.getText());
			Matcher matcher2 = p2.matcher(t6.getText());
			Matcher matcher3 = p3.matcher(t7.getText());
			Matcher matcher4 = p4.matcher(t8.getText());
			Matcher matcher5 = p5.matcher(t9.getText());
			Matcher matcher6 = p6.matcher(t10.getText());
			do_update();
			int intinsert=0;
		    Boolean flag = false;
		    if(t2.getText().equals("")||t3.getText().equals("")||t4.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please Fill All The Information","Error",JOptionPane.ERROR_MESSAGE);
				t2.requestFocus();
			}
			if(this.t5.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			else if(this.t5.getText().length()!=10)
			{
				JOptionPane.showMessageDialog(null,"Enter correct Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			else if(this.t6.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Phone no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			if(this.t7.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Specification","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
			}
			else if(this.t8.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Monthly Income","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
			}
			else if(this.t9.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Ex-Showroom Price With LBT","Error",JOptionPane.ERROR_MESSAGE);
				t9.requestFocus();
			}
			else if(this.t10.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Ex-Showroom Price Without LBT","Error",JOptionPane.ERROR_MESSAGE);
				t10.requestFocus();
			}
			else
			{
				if (!matcher.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Phone Number must be in the form (eg.0253-2123456)","Error",JOptionPane.ERROR_MESSAGE);
					t6.requestFocus();
   				}
				if (matcher1.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Enter only Digits in Field Mobile No..","Error",JOptionPane.ERROR_MESSAGE);
					t5.requestFocus();
   				}
				if (matcher2.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Enter only Digits in field Phone..","Error",JOptionPane.ERROR_MESSAGE);
					t6.requestFocus();
   				}
				else if (matcher3.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Enter only Digits in field Monthly Income..","Error",JOptionPane.ERROR_MESSAGE);
					t8.requestFocus();
   				}
				else if (matcher4.matches()) 
				{
  	  				JOptionPane.showMessageDialog(null,"Enter only Digits in field Ex-Showroom Price With LBT..","Error",JOptionPane.ERROR_MESSAGE);
					t9.requestFocus();
   				}
				else if (matcher5.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Enter only Digits in field Ex-Showroom Price Without LBT..","Error",JOptionPane.ERROR_MESSAGE);
					t10.requestFocus();
      			}
				else
			    {
					int r=JOptionPane.showConfirmDialog(null,"Do You Want To Save Record ?","THANK YOU",JOptionPane.YES_NO_OPTION);
		    		if(r==JOptionPane.YES_OPTION)
			   		try 
			    	{			
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		           		con = DriverManager.getConnection("jdbc:odbc:tybsc1");
						Statement stat1 = con.createStatement();
						ResultSet rs = stat1.executeQuery("select * from payinfo");
					    while(rs.next())
						{
							if(rs.getInt(1) == Integer.parseInt(t1.getText()))
							{
								flag = true;
							}
						}
						if(flag == false)
						{
							PreparedStatement pstmt = con.prepareStatement("insert into payinfo values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					    	pstmt.setInt(2,Integer.parseInt(t1.getText()));//no
							pstmt.setString(1,""+pay.getSelectedItem());//pay
					    	pstmt.setString(3,t2.getText());//nm
					    	pstmt.setString(4,t3.getText());//temp
			   			 	pstmt.setString(5,t4.getText());//perm
					    	pstmt.setString(6,t5.getText());//mob
				 		   	pstmt.setString(7,t6.getText());//lan
					    	pstmt.setString(8,""+work.getSelectedItem());//wrk
					    	pstmt.setString(9,t7.getText()); //specify
					    	pstmt.setDouble(10,Double.parseDouble(t8.getText())); //mon income
					    	pstmt.setDouble(11,Double.parseDouble(t9.getText())); //expricewithLBT
					    	pstmt.setDouble(12,Double.parseDouble(t10.getText()));//expricewithoutLBT
					    	intinsert = pstmt.executeUpdate();
					    	pstmt.close();
					    	con.close();
						}
						if(flag == true)
						{
							JOptionPane.showMessageDialog(null,"Customer Already Exists","Error",JOptionPane.ERROR_MESSAGE);
							t1.setText("");
							t2.setText("");
		    				t3.setText("");
		    				t4.setText("");
		    				t5.setText("");
		    				t6.setText("");
		    				t7.setText("");
		    				t8.setText("");    
		    				t9.setText("");
		    				t10.setText("");
						}
					}
				    catch (SQLException e4) 
				    {}
		    		catch (Exception ex3) 
		   			{}
				    if(intinsert==1)
		    		{
				    	JOptionPane.showMessageDialog(null,"Record Save Successfully");
				    	t1.setText("");
		    			t2.setText("");
		 			   	t3.setText("");
		    			t4.setText("");
				    	t5.setText("");
				    	t6.setText("");
				    	t7.setText("");
				    	t8.setText("");    
				    	t9.setText("");
				    	t10.setText("");	
				    }
		  		}
			}	
		}
		if(ae.getSource()==b5)
		{
            int intupdate = 0;
			Pattern pattern = Pattern.compile("\\d{3}-\\d{7}");
			Pattern p1 = Pattern.compile("^[A-Za-z]+$");
			Pattern p2 = Pattern.compile("^[A-Za-z]+$");
			Pattern p3 = Pattern.compile("^[A-Za-z]+$");
			Pattern p4 = Pattern.compile("^[A-Za-z]+$");
			Pattern p5 = Pattern.compile("^[A-Za-z]+$");
        	Matcher matcher = pattern.matcher(t5.getText());
			Matcher matcher1 = p1.matcher(t6.getText());
			Matcher matcher2 = p2.matcher(t7.getText());
			Matcher matcher3 = p3.matcher(t8.getText());
			Matcher matcher4 = p4.matcher(t9.getText());
			Matcher matcher5 = p5.matcher(t10.getText());
			do_update();
		    Boolean flag=false;
		    if(t2.getText().equals("")||t3.getText().equals("")||t4.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please Fill All The Information","Error",JOptionPane.ERROR_MESSAGE);
				t2.requestFocus();
			}
			else if(this.t5.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			else if(this.t5.getText().length()!=10)
			{
				JOptionPane.showMessageDialog(null,"Enter correct Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			if(this.t6.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Phone no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			if(this.t7.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Specification","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
			}
			else if(this.t8.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Monthly Income","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
			}
			else if(this.t9.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Price","Error",JOptionPane.ERROR_MESSAGE);
				t9.requestFocus();
			}
			else if(this.t10.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Down Payment","Error",JOptionPane.ERROR_MESSAGE);
				t10.requestFocus();
			}
			else
			{
				if (!matcher.matches()) 
				{
   	  				JOptionPane.showMessageDialog(null,"Phone Number must be in the form (eg.0253-2123456)","Error",JOptionPane.ERROR_MESSAGE);
					t6.requestFocus();
   				}
				else if (matcher1.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in Field Mobile No..","Error",JOptionPane.ERROR_MESSAGE);
					t5.requestFocus();
      			}
				if (matcher2.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Phone..","Error",JOptionPane.ERROR_MESSAGE);
					t6.requestFocus();
      			}
				else if (matcher3.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Monthly Income..","Error",JOptionPane.ERROR_MESSAGE);
					t8.requestFocus();
      			}
				else if (matcher4.matches()) 
				{
					JOptionPane.showMessageDialog(null,"Enter only Digits in field Price..","Error",JOptionPane.ERROR_MESSAGE);
					t9.requestFocus();
      			}
				else if (matcher5.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Down Payment..","Error",JOptionPane.ERROR_MESSAGE);
					t10.requestFocus();
      			}
			    else
			    {
					int r=JOptionPane.showConfirmDialog(null,"Do You Want To Update Record ?","THANK YOU",JOptionPane.YES_NO_OPTION);
		    		if(r==JOptionPane.YES_OPTION)
					try 
					{
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
						System.out.println ("In Update Got Connection:"+con);
						PreparedStatement pstmt3 = con.prepareStatement("update payinfo set pay ='"+pay.getSelectedItem()
						+"',name ='"+t2.getText() +"',addt ='"+t3.getText()+"',addp ='"+t4.getText()
						+"',phno='"+t5.getText()+"',phlan ='"+t6.getText()
						+"',working ='"+work.getSelectedItem()+"',specify ='"+t7.getText()+"',monthlyincome ='"+t8.getText()
				    	+"',price='"+t9.getText()+"',downpay ='"+t10.getText()+"',totmonth='"+t11.getText()+"',emi='"+t12.getText()
						+"' where cno ="+Integer.parseInt(t1.getText()));
					 
						intupdate = pstmt3.executeUpdate();				
				   		pstmt3.close();
						con.close();
			    	}
			   	 	catch (SQLException e8) 
			    	{
			    	}
			    	catch(Exception ex8)
			    	{
			    	}
			   	}
			}
			if(intupdate == 1)
			{
				JOptionPane.showMessageDialog(null,"Record Updated SuccessFully");
				t1.setText("");
			   	t2.setText("");
			   	t3.setText("");
			   	t4.setText("");
			   	t5.setText("");
			   	t6.setText("");
			   	t7.setText("");
			   	t8.setText("");
			   	t9.setText("");
			   	t10.setText("");
			}		
		} 
		if(ae.getSource()==b6)
		{
			dispose();
		 	billinfo bi=new billinfo();
		}
        if(ae.getSource()==b7)
        {
			String custid = JOptionPane.showInputDialog("Enter the Customer Number : ");
		   	if(custid==null)
		   	{
				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		   	}
		   	else
		   	{                
		   	 	try
                { 
					int cust=Integer.parseInt(custid);
                    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					Statement st= con.createStatement();
					rs1=st.executeQuery("select * from payinfo where cno="+cust);
	                if(rs1.next())  
    	            { 
			   	    	t1.setText(rs1.getString(2));
						pay.setSelectedItem(rs1.getString(1));
			          	t2.setText(rs1.getString(3));
			          	t3.setText(rs1.getString(4));
			          	t4.setText(rs1.getString(5));
						t5.setText(rs1.getString(6));
  						t6.setText(rs1.getString(7));
						work.setSelectedItem(rs1.getString(8));
						t7.setText(rs1.getString(9));
						t8.setText(rs1.getString(10));
						t9.setText(rs1.getString(11));
						t10.setText(rs1.getString(12));
                  	}
                    else
                    {
                      	String msg= "Record Does not exist/give customer ID";
                      	JOptionPane.showMessageDialog((Component)null,msg,"SHAAN CARS Pvt. Ltd.",JOptionPane.INFORMATION_MESSAGE);
                    }
               	}
               	catch(SQLException se)
               	{
                    System.err.println(se);
               	}
               	catch(Exception e)
               	{
                	System.err.println(e);
            	}
        	}
    	} 
	}
	public static void main(String args[])
    {
    	new payinfo();
    }
}