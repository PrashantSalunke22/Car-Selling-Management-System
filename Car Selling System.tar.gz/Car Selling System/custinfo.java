import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


class custinfo extends JFrame implements ActionListener
{
	
	int updateenqno = 0;
    int custNo;
	
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,addrs,phlabel;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JButton b1,b2,b3,b4,b5,b6; 
	Container cp;
	JPanel p1,p2,p3,p4;
	JComboBox gen = new JComboBox();
	JComboBox color = new JComboBox();
    JComboBox car = new JComboBox();
	JComboBox wh = new JComboBox();
	Font f1,f2,f3;
    ResultSet rs1;
    Statement s1;
    Connection con; 
	custinfo()
	{
		super("Customer Information Form");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
		try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    con = DriverManager.getConnection("jdbc:odbc:tybsc1");
		    s1=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs1 = s1.executeQuery("select * from custinfo");
            while(rs1.next())
            {
            	custNo=rs1.getInt(1);
            }
            custNo++;
        }
        catch(Exception e)
		{
			System.out.println(e);
        }
        f1=new Font("Times New Roman",Font.BOLD,15);
        f2=new Font("Times New Roman",Font.BOLD,25);
        f3=new Font("Times New Roman",Font.BOLD,10);
		
		l1=new JLabel("SHAAN CARS Pvt. Ltd.");
		l1.setFont(new Font("Times New Roman",Font.ITALIC,25));
        l1.setForeground(Color.red);
        
        addrs=new JLabel("E-3,MIDC Area,Satpur,Nashik 422007");
		addrs.setFont(new Font("Times New Roman",Font.BOLD,15));
		addrs.setForeground(Color.black);
		
		phlabel=new JLabel("Ph: 0253-2351279");
		phlabel.setFont(new Font("Times New Roman",Font.BOLD,15));
		phlabel.setForeground(Color.black);
		
    	
		l2=new JLabel(" 1:\t CUSTOMER ID");
		l2.setFont(f1);
        l2.setForeground(Color.black);
		
		t1=new JTextField(5);
		t1.setFont(f1);
        t1.setForeground(Color.black);
		t1.setText(String.valueOf(custNo++));
    	t1.setEditable(false); 

		l3=new JLabel(" 2:\t CUSTOMER NAME");
		l3.setFont(f1);
        l3.setForeground(Color.black);
	
		t2=new JTextField(5);
		t2.setFont(f1);
        t2.setForeground(Color.black);
	
		l4=new JLabel(" 3:\t GENDER");
		l4.setFont(f1);
        l4.setForeground(Color.black);
        
		gen.addItem("Male");
        gen.addItem("Female");
		
        l5=new JLabel(" 4:\t Age");
		l5.setFont(f1);
        l5.setForeground(Color.black);
		
		t3=new JTextField(5);
		t3.setFont(f1);
        t3.setForeground(Color.black);
		
		l6=new JLabel(" 5:\t ADDRESS (TEMP)");
		l6.setFont(f1);
        l6.setForeground(Color.black);
		
		t4=new JTextField(5);
		t4.setFont(f1);
        t4.setForeground(Color.black);
		
		l7=new JLabel(" 6:\t ADDRESS (PERM)");
		l7.setFont(f1);
        l7.setForeground(Color.black);
        
        t5=new JTextField(5);
		t5.setFont(f1);
        t5.setForeground(Color.black);
		
		l8=new JLabel(" 7:\t PHONE NO.(Mob)");
		l8.setFont(f1);
        l8.setForeground(Color.black);
        
        t6=new JTextField(5);
		t6.setFont(f1);
        t6.setForeground(Color.black);
		
		l9=new JLabel(" 8:\t PHONE NO.(Res)");
		l9.setFont(f1);
        l9.setForeground(Color.black);
		
		t7=new JTextField(5);
		t7.setFont(f1);
        t7.setForeground(Color.black);
		
		l10=new JLabel(" 9:\t CAR ");
		l10.setFont(f1);
        l10.setForeground(Color.black);

        car.addItem(" *  Maruti 800 ");
        car.addItem(" *  Maruti OMNI ");
        car.addItem(" *  ALTO ");
        car.addItem(" *  ALTO 800 ");
        car.addItem(" *  Eeco ");
        car.addItem(" *  WagonR ");
        car.addItem(" *  WagonR Duo ");
        car.addItem(" *  Ritz ");
        car.addItem(" *  Swift ");
        car.addItem(" *  Swift Desire ");
        car.addItem(" *  SX4 ");
        car.addItem(" *  Ertiga ");
        car.addItem(" *  Grand Vitara ");
		
		l11=new JLabel(" 10:\t COLOUR ");
		l11.setFont(f1);
        l11.setForeground(Color.black);
		
		color.addItem(" *  Midnight Black");
        color.addItem(" *  Blue Blaze");
        color.addItem(" *  Silky Silver");
		color.addItem(" *  Superior White");
		color.addItem(" *  Bright Red");
		color.addItem(" *  Glistening Grey");
		
		l12=new JLabel(" 12:\t DATE OF PURCHASE");
		l12.setFont(f1);
        l12.setForeground(Color.black);

		t8=new JTextField(5);		
		t8.setFont(f1);
        t8.setForeground(Color.black);

		l13=new JLabel(" 11:\t WHEELS");
		l13.setFont(f1);
        l13.setForeground(Color.black);
		
		wh.addItem(" *  MackWheels ");
        wh.addItem(" *  AlloyWheels ");
        
		b1=new JButton("CLEAR");
		b1.setFont(f1);
		b1.addActionListener(this);
		
		b2=new JButton("NEXT");
		b2.setFont(f1);
		b2.addActionListener(this);
		
		b3=new JButton("BACK");
		b3.setFont(f1);
		b3.addActionListener(this);
		
		b4=new JButton("SAVE");
		b4.setFont(f1);
		b4.addActionListener(this);
		
		b5=new JButton("UPDATE");
		b5.setFont(f1);
		b5.addActionListener(this);
        
        b6=new JButton("SEARCH");
		b6.setFont(f1);
		b6.addActionListener(this);
                
		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p3=new JPanel();
		p3.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p1.setLayout(new FlowLayout());
        p2.setLayout(new GridLayout(13,2));
        p3.setLayout(new FlowLayout());

        p1.add(l1);
        p1.add(addrs);
        p1.add(phlabel);

        p2.add(l2);      
		p2.add(t1); 

		p2.add(l3);		
		p2.add(t2);
		
		p2.add(l4);		
		p2.add(gen);
    	
    	p2.add(l5);		
		p2.add(t3);
		
		p2.add(l6);		
		p2.add(t4);
		
		p2.add(l7);
		p2.add(t5);
		
		p2.add(l8);
		p2.add(t6);
		
		p2.add(l9);
		p2.add(t7);
 		
 		p2.add(l10);
		p2.add(car);
	
 		p2.add(l11);
		p2.add(color);
	
		p2.add(l12);
		p2.add(t8);
		
		p2.add(l13);
		p2.add(wh);
		
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		p3.add(b5);
		p3.add(b6);
				
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p2,BorderLayout.CENTER);
		cp.add(p3,BorderLayout.SOUTH);

		      
		setBounds(130,100,800,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void do_update()
	{
		Connection cn;
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement stat = cn.createStatement();
			ResultSet rs = stat.executeQuery("select * from custinfo");
			System.out.println("Connection is done..!");
			while(rs.next())
			{
				updateenqno = rs.getInt(1);				
			}
			updateenqno = updateenqno + 1;
		}
	    catch (SQLException se) 
	    {
	    	System.out.println ("Ex1:"+se);
	    }
	    catch (Exception eg) 
	    {
	    	System.out.println ("Ex2:"+eg);
	    }
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str = ae.getActionCommand();
	    Connection con ;
	    Statement stat ;
             
		if(ae.getSource()==b1)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			t8.setText("");
		}
		if(ae.getSource()==b2)
		{
			dispose();
		 	payinfo pi=new payinfo();
		}
		if(ae.getSource()==b3)
		{
		 	dispose();
		 	carinfo1 bi=new carinfo1();
		}
		if(ae.getSource()==b5)
		{
			int intupdate = 0;
			Pattern pattern = Pattern.compile("\\d{3}-\\d{7}");
			Pattern p1 = Pattern.compile("^[A-Za-z]+$");
			Pattern p2 = Pattern.compile("^[A-Za-z]+$");
			Pattern p3 = Pattern.compile("^[A-Za-z]+$");
			Pattern p4 = Pattern.compile("^[A-Za-z]+$");
			Pattern p5 = Pattern.compile("^[A-Za-z]+$");
        	Matcher matcher = pattern.matcher(t7.getText());
			Matcher matcher1 = p1.matcher(t6.getText());
			Matcher matcher2 = p2.matcher(t7.getText());
			Matcher matcher3 = p3.matcher(t1.getText());
			Matcher matcher4 = p4.matcher(t3.getText());
			Matcher matcher5 = p5.matcher(t8.getText());
			do_update();
		    Boolean flag = false;
			if(this.t2.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Customer Name.","Error",JOptionPane.ERROR_MESSAGE);
				t2.requestFocus();
			}
			if(this.t3.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Age.","Error",JOptionPane.ERROR_MESSAGE);
				t3.requestFocus();
			}
			if(this.t4.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Temporary Address.","Error",JOptionPane.ERROR_MESSAGE);
				t4.requestFocus();
			}
			if(this.t5.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Permanant Address.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			if(this.t6.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			else if(this.t6.getText().length()!=10)
			{
				JOptionPane.showMessageDialog(null,"Enter correct Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			if(this.t7.getText().length()==0)
			{ 
				JOptionPane.showMessageDialog(null,"Please Enter Phone no.","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
			}
			else if(this.t8.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Date Of Purchase.","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
			}
			if(!matcher.matches()) 
			{
    	  			JOptionPane.showMessageDialog(null,"Phone Number must be in the form (eg.0253-2123456)","Error",JOptionPane.ERROR_MESSAGE);
					t7.requestFocus();
      		}
			if (matcher1.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in Field Mobile No..","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
      		}	
			else if (matcher2.matches()) 
			{
				JOptionPane.showMessageDialog(null,"Enter only Digits in field Phone..","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
      		}
			else if (matcher4.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in field Age..","Error",JOptionPane.ERROR_MESSAGE);
				t3.requestFocus();
      		}
			else if (matcher5.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in field Date of purchase..","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
      		}
			else
			{
		  		int r=JOptionPane.showConfirmDialog(null,"Do You Want To Update Record ?","THANK YOU",JOptionPane.YES_NO_OPTION);
		   		if(r==JOptionPane.YES_OPTION)
				try 
				{
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					System.out.println ("Updated successfully at connection :"+con);
					
					PreparedStatement pstmt3 = con.prepareStatement("update custinfo set custname ='"+t2.getText()
					+"',gender ='"+gen.getSelectedItem() +"',addperm ='"+t4.getText()+"',addtemp ='"+t5.getText()
					+"',car ='"+car.getSelectedItem()+"',color ='"+color.getSelectedItem()+"',wheel ='"+wh.getSelectedItem()
					+"',dateofpur ='"+t8.getText()+"',age ='"+t3.getText()+"',phno ='"+t6.getText()
					+"',phlan ='"+t7.getText()+"' where custno ="+Integer.parseInt(t1.getText()));
					 
					intupdate = pstmt3.executeUpdate();				
				    pstmt3.close();
					con.close();
			    }
			    catch (SQLException e8) 
			    {
				System.out.println(e8);
				JOptionPane.showMessageDialog(null,e8,"Error",JOptionPane.ERROR_MESSAGE);
			    }
			    catch(Exception ex8)
			    {
				JOptionPane.showMessageDialog(null,ex8,"Error",JOptionPane.ERROR_MESSAGE);
			    }
			}
			if(intupdate == 1)
			{
				JOptionPane.showMessageDialog(null,"Record Updated SuccessFully");
				t1.setText(null);
				t2.setText(null);
				t3.setText(null);
				t4.setText(null);
				t5.setText(null);
				t6.setText(null);
				t7.setText(null);
				t8.setText(null);
			}			
		}
		if(ae.getSource()==b4)
		{
			Pattern pattern = Pattern.compile("\\d{3}-\\d{7}");
			Pattern p1 = Pattern.compile("^[A-Za-z]+$");
			Pattern p2 = Pattern.compile("^[A-Za-z]+$");
			Pattern p3 = Pattern.compile("^[A-Za-z]+$");
			Pattern p4 = Pattern.compile("^[A-Za-z]+$");
			Pattern p5 = Pattern.compile("^[A-Za-z]+$");
        	Matcher matcher = pattern.matcher(t7.getText());
			Matcher matcher1 = p1.matcher(t6.getText());
			Matcher matcher2 = p2.matcher(t7.getText());
			Matcher matcher3 = p3.matcher(t1.getText());
			Matcher matcher4 = p4.matcher(t3.getText());
			Matcher matcher5 = p5.matcher(t8.getText());
			do_update();
			int intinsert=0;
		    Boolean flag = false;
		 
		 	if(this.t2.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Customer Name.","Error",JOptionPane.ERROR_MESSAGE);
				t2.requestFocus();
			}
			if(this.t3.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Age.","Error",JOptionPane.ERROR_MESSAGE);
				t3.requestFocus();
			}
			if(this.t4.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Temporary Address.","Error",JOptionPane.ERROR_MESSAGE);
				t4.requestFocus();
			}
			if(this.t5.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Permanent Address.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			if(this.t6.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			else if(this.t6.getText().length()!=10)
			{
				JOptionPane.showMessageDialog(null,"Enter correct Mobile no.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}
			if(this.t7.getText().length()==0)
			{ 
				JOptionPane.showMessageDialog(null,"Please Enter Phone no.","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
			}
			if(this.t8.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Date Of Purchase.","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
			}
			if (!matcher.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Phone Number must be in the form (eg.0253-2123456)","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
      		}
			else if (matcher1.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in Field Mobile No..","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}	
			if (matcher2.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in field Phone..","Error",JOptionPane.ERROR_MESSAGE);
				t7.requestFocus();
      		}
			else if (matcher4.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in field Age..","Error",JOptionPane.ERROR_MESSAGE);
				t3.requestFocus();
      		}
			if (matcher5.matches()) 
			{
    	  		JOptionPane.showMessageDialog(null,"Enter only Digits in field Date of purchase..","Error",JOptionPane.ERROR_MESSAGE);
				t8.requestFocus();
      		}
			else
			{
				int r=JOptionPane.showConfirmDialog(null,"Do You Want To Save Record ?","THANK YOU",JOptionPane.YES_NO_OPTION);
		    	if(r==JOptionPane.YES_OPTION)
				try 
				{			
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					Statement stat1 = con.createStatement();
					ResultSet rs = stat1.executeQuery("select * from custinfo");
					System.out.println("got connection in insert");
					while(rs.next())
					{
						if(rs.getInt(1) == Integer.parseInt(t1.getText()))
						{
							flag = true;
						}
					}
					if(flag == false)
					{
						PreparedStatement pstmt = con.prepareStatement("insert into custinfo values (?,?,?,?,?,?,?,?,?,?,?,?)");
					   	pstmt.setInt(1,Integer.parseInt(t1.getText()));//no
				    	pstmt.setString(2,t2.getText());//nm
				    	pstmt.setString(3,""+gen.getSelectedItem());// M/F
				    	pstmt.setString(4,t3.getText());//age
				    	pstmt.setString(5,t4.getText());//addp
				    	pstmt.setString(6,t5.getText());//addt
				    	pstmt.setString(7,t6.getText());//phno
				    	pstmt.setString(8,t7.getText());//phlan
				    	pstmt.setString(9,""+car.getSelectedItem()); //car
				    	pstmt.setString(10,""+color.getSelectedItem()); //color
				    	pstmt.setString(11,""+wh.getSelectedItem()); //wheel
				    	pstmt.setString(12,t8.getText());//date
			        
			        	intinsert = pstmt.executeUpdate();
			        	pstmt.close();
			    		con.close();
					}
					if(flag == true)
					{
						JOptionPane.showMessageDialog(null,"Customer Already Exists","Error",JOptionPane.ERROR_MESSAGE);
						t1.setText(null);
					}
				}
			    catch (SQLException e4) 
			    {
					JOptionPane.showMessageDialog(null,e4,"Error",JOptionPane.ERROR_MESSAGE);
			    }
			    catch (Exception ex3) 
				{
					JOptionPane.showMessageDialog(null,ex3,"Error",JOptionPane.ERROR_MESSAGE);
				}
				if(intinsert == 1)
				{
		    		JOptionPane.showMessageDialog(null,"Record Saved Successfully");
		    		t1.setText(null);
		    		t2.setText(null);
					t3.setText(null);
		    		t4.setText(null);
		    		t5.setText(null);
		    		t6.setText(null);
		    		t7.setText(null);
		    		t8.setText(null);    	
				}
			}
		}	
    	if(ae.getSource()==b6)
        {
			String custid = JOptionPane.showInputDialog("Enter the Customer Number : ");
			if(custid==null)
			{
				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		  	}
		   	else
		   	{                
				try
                { 
                	int cust=Integer.parseInt(custid);
                    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					Statement st= con.createStatement();
			   		ResultSet rs1=st.executeQuery("select * from custinfo where custno="+custid);
                    if(rs1.next())
                    {
			   	        t1.setText(rs1.getString(1));
			          	t2.setText(rs1.getString(2));
			          	gen.setSelectedItem(rs1.getString(3));
			          	t3.setText(rs1.getString(4));
			          	t4.setText(rs1.getString(5));
						t5.setText(rs1.getString(6));
  						t6.setText(rs1.getString(7));
						t7.setText(rs1.getString(8));
						car.setSelectedItem(rs1.getString(9));
						color.setSelectedItem(rs1.getString(10));
						wh.setSelectedItem(rs1.getString(11));
						t8.setText(rs1.getString(12));
					}
                    else
                    {
                    	String msg= "Record Does not exist/give customer ID";
                        JOptionPane.showMessageDialog((Component)null,msg,"SHAAN CARS Pvt. Ltd.",JOptionPane.INFORMATION_MESSAGE);
					}
				}
                catch(SQLException se)
                {
                	System.err.println(se);
				}
                catch(Exception e)
                {
                	System.err.println(e);
				}
			}
		}
	}
	public static void main(String arg[])
    {
    	custinfo ci=new custinfo();
    }
}
/********************************************

	if(str.equals("vi"))
	{
		if(t1.getText().equals(""))
		{
			JOptionPane.showMessageDialog(null,"Please enter the customer number","Error",JOptionPane.ERROR_MESSAGE);
		}
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			System.out.println ("Got Connection :"+con);
			stat = con.createStatement();
		    ResultSet rs = stat.executeQuery("select * from custinfo");
		    while(rs.next())
		    {
		    	if(rs.getInt(1) == Integer.parseInt(tfno.getText()))
		    	{
		    		tfname.setEditable(true);
		    		tfadd.setEditable(true);
		    		tfage.setEditable(true);
		    		tfr.setEditable(true);
		    		tfo.setEditable(true);
		    		tfm.setEditable(true);
		    		tfemail.setEditable(true);
		    		tfname.setText(rs.getString(2));
		    		tfadd.setText(rs.getString(3));		    		
		    		tfage.setText(""+rs.getInt(4));			    		
		    		tfr.setText(""+rs.getInt(5));			    		
		    		tfo.setText(""+rs.getInt(6));
		    		tfm.setText(""+rs.getInt(7));
		    		tfemail.setText(rs.getString(8));    		
		    	}
		    }			    
		    con.close();
		    stat.close();			    
		 }  
		catch (SQLException e7) 
	    {
	    	JOptionPane.showMessageDialog(null,"Record Not Found","Error",JOptionPane.ERROR_MESSAGE);
	    	tfno.setText(null);
	    	tfname.setText(null);
	    	tfage.setText(null);
	    	tfadd.setText(null);
	    	tfr.setText(null);
	    	tfo.setText(null);
	    	tfemail.setText(null);
	    	tfm.setText(null);
	    }
	    catch (Exception ex5) 
	    { }
	}
	if(str.equals("sea"))
	{
		Boolean flag1 = false;
		System.out.println ("In search");
		if(tfno.getText().equals(""))
		{
			System.out.println ("chk1");
			JOptionPane.showMessageDialog(null,"Please enter the custer no","Error",JOptionPane.ERROR_MESSAGE);
		}
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			System.out.println ("Got Connection :"+con);
			stat = con.createStatement();
		    ResultSet rs = stat.executeQuery("select * from cust");
		    while(rs.next())
		    {
		    	if(rs.getInt(1) == Integer.parseInt(tfno.getText()))
		    	{
		    		flag1 = true;
		    		tfname.setText(rs.getString(2));
		    		tfadd.setText(rs.getString(3));		    		
		    		tfage.setText(""+rs.getInt(4));			    		
		    		tfr.setText(""+rs.getInt(5));			    		
		    		tfo.setText(""+rs.getInt(6));
		    		tfm.setText(""+rs.getInt(7));
		    		tfemail.setText(rs.getString(8));    		
		    		tfname.setEditable(false);
		    		tfadd.setEditable(false);
		    		tfage.setEditable(false);
		    		tfr.setEditable(false);
		    		tfo.setEditable(false);
		    		tfm.setEditable(false);
		    		tfemail.setEditable(false);
		    	}
		    }
		    if(flag1 == false)
		    {
		    	JOptionPane.showMessageDialog(null,"Record Not Found","Error",JOptionPane.ERROR_MESSAGE);
		    	tfno.setText(null);
		    	tfname.setText(null);
		    	tfage.setText(null);
		    	tfadd.setText(null);
		    	tfr.setText(null);
		    	tfo.setText(null);
		    	tfemail.setText(null);
		    	tfm.setText(null);
		    }
		    con.close();
		    stat.close();			    
	    }
	    catch (SQLException e1) 
	    {
	    	System.out.println ("Exception Generated1:"+e1);
	    	e1.printStackTrace();
	    }
	    catch (Exception ex) 
	    { }
	}
	*/
	
	/*	if(str.equals(""))
		{	 
			if(ae.getSource()==b6)
			{
				JOptionPane.showMessageDialog(null,"Please enter the customer number","Error",JOptionPane.ERROR_MESSAGE);
				
			}
			try 
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con = DriverManager.getConnection("jdbc:odbc:tybsc1");
				System.out.println ("In delete Got Connection:"+con);
				Statement stmt3 = con.createStatement(); 
				stmt3.executeQuery("delete from custinfo where Cust_No = "+Integer.parseInt(t1.getText()));
				stmt3.close();
				con.close();
			}
			catch (SQLException e8) 
			{
				JOptionPane.showMessageDialog(null,"Record Deleted Successfully");
			    t1.setText(null);
			    t2.setText(null);
			    t3.setText(null);
			    t4.setText(null);
			    t5.setText(null);
			    t6.setText(null);
			    t7.setText(null);
		    }
		    catch(Exception ex8)
			{ }
		}*/