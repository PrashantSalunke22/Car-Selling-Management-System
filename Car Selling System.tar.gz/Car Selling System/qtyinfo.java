import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.io.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class qtyinfo extends JFrame implements ActionListener, ItemListener
{

	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
	JTextField t1,t2,t3,t4,t5,t6,t7;
	JButton b1,b2,b3,b4,b5,b6; 
	Container cp;
	JComboBox car = new JComboBox();
	JPanel p1,p2,p3,p4;
	Font f1,f2,f3;
	int updateenqno = 0;
	qtyinfo()
	{
		super("Stock Information");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		try
        {
    	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
		f1=new Font("Times New Roman",Font.BOLD,15);
        f2=new Font("Times New Roman",Font.BOLD,45);
        f3=new Font("Times New Roman",Font.BOLD,25);

        l1=new JLabel(" SHAAN CARS Pvt. Ltd. ");
		l1.setFont(f2);
        l1.setForeground(Color.red);
		
		l2=new JLabel("\t SELECT CAR NAME ");
		l2.setFont(f3);
	     
	    l3=new JLabel("\t Colours ");
		l3.setFont(f3);
        l3.setForeground(Color.red);
        
		l4=new JLabel("\t Quantity ");
		l4.setFont(f3);
		l4.setForeground(Color.red);
        
        l11=new JLabel("\t Car No. ");
		l11.setFont(f3);
		l11.setForeground(Color.red);
       
        t7=new JTextField(5);
		t7.setFont(f1);
		t7.setEditable(true);
				
		l5=new JLabel(" 1: Midnight Black ");
		l5.setFont(f1);
		
		t1=new JTextField(5);
		t1.setFont(f1);
		
        l6=new JLabel(" 2: Blue Blaze ");
		l6.setFont(f1);
		
		t2=new JTextField(5);
		t2.setFont(f1);
		
		l7=new JLabel(" 3: Silky Silver ");
		l7.setFont(f1);
		
		t3=new JTextField(5);
		t3.setFont(f1);
		
		l8=new JLabel(" 4: Superior White ");
		l8.setFont(f1);
		
		t4=new JTextField(5);
		t4.setFont(f1);
				
		l9=new JLabel(" 5: Bright Red ");
		l9.setFont(f1);
		
		t5=new JTextField(5);
		t5.setFont(f1);
		
		l10=new JLabel(" 5: Glistening Grey ");
		l10.setFont(f1);
		
		t6=new JTextField(5);
		t6.setFont(f1);
		
		b1=new JButton("HOME");
		b1.setFont(f1);
		b1.addActionListener(this);
		
		b2=new JButton("SHOW");
		b2.setFont(f1);
		b2.addActionListener(this);
		
		b3=new JButton("CLEAR");
		b3.setFont(f1);
		b3.addActionListener(this);
		
		b4=new JButton("ADD");
		b4.setFont(f1);
		b4.addActionListener(this);
		
        car.addItem(" 1 - Maruti 800 ");
        car.addItem(" 2 - Maruti OMNI ");
        car.addItem(" 3 - ALTO ");
        car.addItem(" 4 - ALTO 800 ");
        car.addItem(" 5 - Eeco ");
        car.addItem(" 6 - WagonR ");
        car.addItem(" 7 - WagonR Duo ");
        car.addItem(" 8 - Ritz ");
        car.addItem(" 9 - Swift ");
        car.addItem(" 10 - Swift Desire ");
        car.addItem(" 11 - SX4 ");
        car.addItem(" 12 - Ertiga ");
        car.addItem(" 13 - Grand Vitara ");
		
		p1=new JPanel();
		p1.setLayout(new FlowLayout());
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 2, true));
		
		p3=new JPanel();
		p3.setLayout(new FlowLayout());
		p3.setBorder(new LineBorder(new Color(198, 100, 100), 2, true));
		
		p4=new JPanel();
		p4.setLayout(new GridLayout(10,2));
		
        p1.add(l1);
      	
      	p4.add(l2);		
		p4.add(car);
		
		p4.add(l11);
		p4.add(t7);
		
		p4.add(l3);		
		p4.add(l4);
		
		p4.add(l5);
		p4.add(t1); 
		
		p4.add(l6);
		p4.add(t2); 
	
		p4.add(l7);
		p4.add(t3); 
		
		p4.add(l8);
		p4.add(t4); 
		
		p4.add(l9);
		p4.add(t5); 
		
		p4.add(l10);
		p4.add(t6);
		
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
	
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p4,BorderLayout.CENTER);
		cp.add(p3,BorderLayout.SOUTH);
		
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    Connection con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from qtyinfo");
			while (rs.next())
			{
				String temp = rs.getString(1);
				car.addItem(temp);
			}
		}
		catch (Exception e)
		{
			String dt = " ERROR";
			String dm = " ERROR : " + e;
			int dtype = JOptionPane.ERROR_MESSAGE;
			JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
		}
		car.addItemListener(this);
		
	    setBounds(130,100,800,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void do_update()
	{
		Connection con;
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	        con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from qtyinfo");
			while(rs.next())
			{
				updateenqno = rs.getInt(1);				
			}
			updateenqno = updateenqno +1;
	    }
	    catch (SQLException se) 
	    {
	    	System.out.println ("Ex1:"+se);
	    }
	    catch (Exception eg) 
	    {
	    	System.out.println ("Ex2:"+eg);
	    }
	}
	public void itemStateChanged(ItemEvent ie)
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	        Connection con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from qtyinfo where Carname = '" + ie.getItem()+"'");
			if (rs.next())
			{
				t7.setText(rs.getString(1));
			}
		}
		catch (Exception e)
		{
			String dt = " ERROR";
			String dm = " ERROR : " + e;
			int dtype = JOptionPane.ERROR_MESSAGE;
			JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
		}
	}
	public void actionPerformed(ActionEvent ae)	
	{
		String str = ae.getActionCommand();
	    Connection con ;
	    Statement stat ;
		if(ae.getSource()==b1)
		{
			dispose();
			homepage hp=new homepage();
		}
		if(ae.getSource()==b2)
		{
		 //show
			if(t7.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please enter the  Valid Car number","Error",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				try 
				{
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			       	con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					stat = con.createStatement();
				    ResultSet rs = stat.executeQuery("select * from qtyinfo");
				    while(rs.next())
				    {
				    	if(rs.getInt(1) == Integer.parseInt(t7.getText()))
				    	{
				    		t1.setText(rs.getString(3));
				    		t2.setText(rs.getString(4));		    		
				    		t3.setText(rs.getString(5));			    		
				    		t4.setText(rs.getString(6));			    		
				    		t5.setText(rs.getString(7));
				    		t6.setText(rs.getString(8));
				    		break;
				    	}
				    }			    
				    con.close();
				    stat.close();			    
				 }  
				catch (SQLException e7) 
			    {
			    	JOptionPane.showMessageDialog(null,"Record Not Found","Error",JOptionPane.ERROR_MESSAGE);
			    }
			    catch (Exception ex5) 
			    { }
			}
		}
		if(ae.getSource()==b3)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
		}
		if(ae.getSource()==b4)
		{
			int intupdate = 0;
			Pattern p1 = Pattern.compile("^[A-Za-z]+$");
			Pattern p2 = Pattern.compile("^[A-Za-z]+$");
			Pattern p3 = Pattern.compile("^[A-Za-z]+$");
			Pattern p4 = Pattern.compile("^[A-Za-z]+$");
			Pattern p5 = Pattern.compile("^[A-Za-z]+$");
			Pattern p6 = Pattern.compile("^[A-Za-z]+$");
			Matcher matcher1 = p1.matcher(t1.getText());
			Matcher matcher2 = p2.matcher(t2.getText());
			Matcher matcher3 = p3.matcher(t3.getText());
			Matcher matcher4 = p4.matcher(t4.getText());
			Matcher matcher5 = p5.matcher(t5.getText());
			Matcher matcher6 = p5.matcher(t6.getText());
			if(this.t1.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Red Quantity.","Error",JOptionPane.ERROR_MESSAGE);
				t1.requestFocus();
			}
			else if(this.t2.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Green Quantity","Error",JOptionPane.ERROR_MESSAGE);
				t2.requestFocus();
			}
			else if(this.t3.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Arial Blue Quantity.","Error",JOptionPane.ERROR_MESSAGE);
				t3.requestFocus();
			}
			else if(this.t4.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Please Enter Black Quantity","Error",JOptionPane.ERROR_MESSAGE);
				t4.requestFocus();
			}
			else if(this.t5.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Enter correct White Quantity.","Error",JOptionPane.ERROR_MESSAGE);
				t5.requestFocus();
			}
			else if(this.t6.getText().length()==0)
			{
				JOptionPane.showMessageDialog(null,"Enter correct Brown Quantity.","Error",JOptionPane.ERROR_MESSAGE);
				t6.requestFocus();
			}		
			else
			{
				if (matcher1.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in Field Red..","Error",JOptionPane.ERROR_MESSAGE);
					t1.requestFocus();
      			}
				else if (matcher2.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Green..","Error",JOptionPane.ERROR_MESSAGE);			
					t2.requestFocus();
      			}
				else if (matcher3.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Arial Blue..","Error",JOptionPane.ERROR_MESSAGE);
					t3.requestFocus();
      			}
				else if (matcher4.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Black..","Error",JOptionPane.ERROR_MESSAGE);
					t4.requestFocus();
      			}
				else if (matcher5.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field White..","Error",JOptionPane.ERROR_MESSAGE);
					t5.requestFocus();
      			}
      			else if (matcher6.matches()) 
				{
    	  			JOptionPane.showMessageDialog(null,"Enter only Digits in field Brown..","Error",JOptionPane.ERROR_MESSAGE);
					t6.requestFocus();
      			}
				else
				{
					int r=JOptionPane.showConfirmDialog(null,"Do You Want To Update Stock ?","THANK YOU",JOptionPane.YES_NO_OPTION);
		    		if(r==JOptionPane.YES_OPTION)
					try 
					{
						String name=(String)car.getSelectedItem();
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		           		con = DriverManager.getConnection("jdbc:odbc:tybsc1");
						System.out.println ("In Update Got Connection:"+con);
						PreparedStatement pt3 = con.prepareStatement("update qtyinfo set red=?, green=?, arial blue=?, black=?, white=?, yellow=? where Carname=?");		
						pt3.setInt(1,Integer.parseInt(t1.getText()));
						pt3.setInt(2,Integer.parseInt(t2.getText()));
						pt3.setInt(3,Integer.parseInt(t3.getText()));
						pt3.setInt(4,Integer.parseInt(t4.getText()));
						pt3.setInt(5,Integer.parseInt(t5.getText()));
						pt3.setInt(6,Integer.parseInt(t6.getText()));
						pt3.setString(7,name);				
					 
						intupdate = pt3.executeUpdate();				
				    }
				    catch (SQLException e8) 
			   		{
						JOptionPane.showMessageDialog(null,e8,"Error",JOptionPane.ERROR_MESSAGE);
				    }
				    catch(Exception ex8)
				    {
						JOptionPane.showMessageDialog(null,ex8,"Error",JOptionPane.ERROR_MESSAGE);
				    }
				}
				if(intupdate == 1)
				{
					JOptionPane.showMessageDialog(null,"Record Updated SuccessFully","Success",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
	}
    public static void main(String arg[])
    {
    	new qtyinfo();
    }
}