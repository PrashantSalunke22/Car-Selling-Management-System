import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import java.util.*;
import java.text.*;
class payinforeport extends JFrame implements WindowListener, ActionListener
{
	int count = 0;
	java.util.Date date3;
	Connection con;
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	
	JButton bprint = new JButton("PRINT");
	JButton bhome = new JButton("BACK");
	
	Font f = new Font("Times New Roman",Font.BOLD,16);
	Font h1 = new Font ("Wide Latin",Font.BOLD,22);
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();

	payinforeport()
	{
		super(" Payment Information");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Container c = getContentPane();
				
		JLabel h2=new JLabel(" Payment Information");
	  	h2.setBounds(300,50,500,30);
	   	h2.setFont(h1);
	   	add(h2);
		
		c.add(p1);
		c.add(p2);
		setSize(1030, 580);
		setLocation(-2,100);

		bprint.addActionListener(this);
		bhome.addActionListener(this);
		bprint.setFont(f);
		bhome.setFont(f);

		p2.add(bprint);
		p2.add(bhome);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			st =con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

			p1.setBounds(0,130, 1024, 350);
			p2.setBounds(0, 648, 0, 0);

			p1.setBackground(new Color(198, 100, 100));
			p2.setBackground(new Color(198, 100, 100));

			p1.setLayout(new BorderLayout());
			p2.setLayout(null);

			bprint.setBounds(400, 500, 100,30);
			bhome.setBounds(550,500,90,30);
			
			bprint.setToolTipText("This Button Prints Document");
			bhome.setToolTipText("This Button Goes to the Main Screen");
			
			String[] colHeads = { "Payment", "Customer id", "Customer name", "Addr(temp.)", "Addr(perm.)", "Phone(Mob.)", "Phone(lan.)", "Working","Specify","Monthly Income", "Price", "Total month"};
			rs = st.executeQuery("select Payment, custid, cname, addt, addp, phno, phlan, wrk, specify, monthlyincome, price, totmonth from payinfo");
			while (rs.next())
			{
				count++;
			}
			Object[][] results = new Object[count][14];
			rs.first();
			for (int i = 0; i < count; i++)
			{
				results[i][0] = rs.getString(1);
				results[i][1] = rs.getString(2);
				results[i][2] = rs.getString(3);
				results[i][3] = rs.getString(4);
				results[i][4] = rs.getString(5);
				results[i][5] = rs.getString(6);
				results[i][6] = rs.getString(7);
				results[i][7] = rs.getString(8);
				results[i][8] = rs.getString(9);
				results[i][9] = rs.getString(10);
				results[i][10] = rs.getString(11);
				results[i][11] = rs.getString(12);
				rs.next();
			}
			JTable table = new JTable(results, colHeads);
			int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
			int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
			JScrollPane jsp = new JScrollPane(table, v, h);
			p1.add(jsp, BorderLayout.CENTER);
		}
		catch (Exception e)
		{
			String dt = " ERROR";
			String dm = " ERROR : " + e;
			int dtype = JOptionPane.ERROR_MESSAGE;
			JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
		}
		setVisible(true);
		c.setBackground(new Color(168, 81, 255));
		addWindowListener(this);
	}
	public static void main(String args[])
	{
	    payinforeport br=new payinforeport();
	}
	public void actionPerformed(ActionEvent a)
	{
		String s = a.getActionCommand();
		if (s.equals("BACK"))
		{
			dispose();
			report rp=new report();
		}
		else
		if(s.equals("PRINT"))
		{
			PrintUtilities.printComponent (this);
		}
	}
	public void windowClosing(WindowEvent w)
	{
		setVisible(false);
	}
	public void windowClosed(WindowEvent w) { }
	public void windowOpened(WindowEvent w) { }
	public void windowActivated(WindowEvent w) { }
	public void windowDeactivated(WindowEvent w) { }
	public void windowIconified(WindowEvent w) { }
	public void windowDeiconified(WindowEvent w) { }
}