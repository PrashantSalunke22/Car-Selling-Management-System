import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.sound.sampled.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
class JButtonStateController implements DocumentListener 
{
 	JButton button;
  	JButtonStateController(JButton button)
  	{
	     	this.button = button ;
  	}
  	public void changedUpdate(DocumentEvent e) 
  	{
    		disableIfEmpty(e);
  	}
  	public void insertUpdate(DocumentEvent e) 
  	{
    		disableIfEmpty(e);
  	}
  	public void removeUpdate(DocumentEvent e) 
  	{
    	disableIfEmpty(e);
  	}
  	public void disableIfEmpty(DocumentEvent e) 
  	{
    	button.setEnabled(e.getDocument().getLength() > 0);
  	}
}
class Login extends JFrame implements ActionListener
{
	JLabel lblname,lblpass,log,pass;
	JTextField txtname;
	JPasswordField txtpass;
	JButton btnlogin,btnexit,btnclear;
	int cnt=0;
	ImageIcon ic = new ImageIcon("Ertiga.png");
	JLabel j2=new JLabel("SHAAN Cars Pvt. Ltd.");
	JLabel j3= new JLabel("E-3,MIDC Area,Satpur,Nashik 422007");
	JLabel j4= new JLabel("Ph: 0253-2351279");
	Connection con;
	Statement st;
	ResultSet rs;
	Document document;
	JLabel j1;
	public Login()
	{
		super("Login Screen");
		Container cp = getContentPane();
		Font f = new Font ("Constantia",Font.BOLD,20);
		Font val = new Font ("Bodoni MT",Font.BOLD,18);
		cp.setLayout(null);
		setLayout(null);
		setSize(800,600);
		
		j2.setBounds(250,10,500,35);
		j2.setFont(new Font ("Bodoni MT",Font.BOLD,35));
		j2.setForeground(new Color(255,0,0));
		cp.add(j2);
		
		j3.setBounds(200,40,800,30);
		j3.setFont(new Font ("Bodoni MT",Font.BOLD,30));
		j3.setForeground(new Color(255,0,0));
		cp.add(j3);
		
		j4.setBounds(300,70,500,30);
		j4.setFont(new Font ("Bodoni MT",Font.BOLD,30));
		j4.setForeground(new Color(255,0,0));
		cp.add(j4);
		
		j1=new JLabel("",ic,JLabel.RIGHT);
		j1.setSize(700,520);
		cp.add(j1);
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		cp.setBackground(new Color(255,200,0));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		lblname=new JLabel("Login Name: ");
		lblname.setBounds(220,430,200,25);
		lblname.setForeground(Color.BLACK);
		lblname.setFont(f);
		add(lblname);
		
		lblpass=new JLabel("Password: ");
		lblpass.setBounds(220,480,200,25);
		lblpass.setFont(f);
		lblpass.setForeground(Color.BLACK);
		add(lblpass);
		
		txtname=new JTextField(15);
		txtname.setBounds(350,430,150,25);
		txtname.setToolTipText("Enter User name");
		txtname.addActionListener(this);
		add(txtname);
		txtname.setDocument(new JTextFieldLimit(15));
		
		txtpass=new JPasswordField(10);
		txtpass.setBounds(350,480,150,25);
		txtpass.setToolTipText("Enter your PASSWORD");
		txtpass.setEchoChar('*');
		add(txtpass);
		txtpass.setDocument(new JTextFieldLimit(10));
		txtpass.addActionListener(this);
		
		btnlogin=new JButton("LOGIN");
		btnlogin.setBounds(230,520,75,25);
		btnlogin.addActionListener (this);
		btnlogin.setToolTipText("This button used for login");
		add(btnlogin);
		
		document = txtname.getDocument();
		document.addDocumentListener(new JButtonStateController(btnlogin));
		
		btnexit=new JButton("EXIT");
		btnexit.setBounds(330,520,75,25);
		btnexit.addActionListener (this);
		btnexit.setToolTipText("This button Exit the Login Screen");
		add(btnexit);
		
		btnclear=new JButton("CLEAR");
		btnclear.setBounds(430,520,75,25);
		btnclear.addActionListener (this);
		btnclear.setToolTipText("This button clear the text of TextBox");
		add(btnclear);
		
		document = txtname.getDocument();
		document.addDocumentListener(new JButtonStateController(btnclear));
		
		setConnection();
		setVisible(true);
	}
	public static void main(String args[])
	{
	     new Login();
	}	
	public void setConnection()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			st = con.createStatement();
		}
		catch (Exception e)
		{
			String dt = " ERROR";
			String dm = " ERROR : " + e;
			int dtype = JOptionPane.ERROR_MESSAGE;
			JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
		}
	}
	public void actionPerformed(ActionEvent a)
	{
		String s1 = a.getActionCommand();
		int txtnm=0,txtpss=0;
		if (s1.equals("EXIT"))
		{
			System.exit(0);
		}
		else
		if ((s1.equals("LOGIN"))||(a.getSource()==txtpass))
		{
			if(this.txtname.getText().length()==0)
		  	{
				this.log.setText("Enter Login name");
		  	}
		  	if(this.txtpass.getText().length()==0)
		  	{
				this.pass.setText("Enter Password");
		  	}
		  	else
		  	{
		   		boolean flag=true;
				try
				{
				 	String s2 = txtname.getText();
					String s3 = txtpass.getText();
					if(s2.equals("Prashant") && s3.equals("salunke"))
					{
						JOptionPane.showMessageDialog(null,"Login Sucsessfully Done..","Welcome",JOptionPane.INFORMATION_MESSAGE);
			   	    	System.out.println("Login Successfully");
						flag=true;
						new homepage();
						setVisible(false);
					}
					else if(s2.equals("Sandip") && s3.equals("sangale"))
					{
						JOptionPane.showMessageDialog(null,"Login Sucsessfully Done..","Welcome",JOptionPane.INFORMATION_MESSAGE);
			   	    	System.out.println("Login Successfully");
						flag=true;
						new homepage();
						setVisible(false);
					}
					else
					{
						String dt = "Error Message";
						String dm = "Sorry..! Try Again, Invalid user name and password..! "; 
						int dtype = JOptionPane.ERROR_MESSAGE;
						JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
						txtpass.setText("");
						txtname.setText("");
						txtname.requestFocus();
					}
				}
				catch (Exception e)
				{
					String dt = "Error Message";
					String dm = "SQL ERROR : " + e;
					int dtype = JOptionPane.ERROR_MESSAGE;
					JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
				}
			}
		}
		else
		if (s1.equals("CLEAR"))
		{
				txtname.setText("");
				txtpass.setText("");
				log.setText("");
				pass.setText("");
				txtname.requestFocus();
		}
	}	
}