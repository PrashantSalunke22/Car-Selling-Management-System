import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.*;
class dialog extends JFrame implements ActionListener
{
	JButton bexit,bok;
    JLabel l1,l2,l3,lbl;
    JTextField t1;
    JPasswordField t2; 
    JPanel p1,p2,p3;
    Container cp;
    Font f1,f2;
    int cnt;
	ImageIcon img;
    dialog()  //constr
    {
   		super("Login Form");
        cp=getContentPane();
        cp.setLayout(new BorderLayout());
        try
        {
	        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex)
        {
    	    System.out.println(ex);
        }    
        f1=new Font("Times New Roman",Font.BOLD,25);
        f2=new Font("Times New Roman",Font.BOLD,45);
        l1=new JLabel("SACHI HONDA");
		l1.setFont(f2);
		l1.setForeground(Color.RED);
                
        l2=new JLabel("Enter UserName");
        l2.setFont(f1);
        l2.setForeground(Color.black);
            
        l3=new JLabel("Enter Password");
        l3.setFont(f1);
        l3.setForeground(Color.black);
                
        t1=new JTextField(10);
        t1.setFont(f1);
        t1.setToolTipText("ENTER YOUR NAME HERE");
            
        t2=new JPasswordField(10);
        t2.setFont(f1);
        t2.setToolTipText("ENTER YOUR PASSWORD HERE");
                
        bok=new JButton("OK");
        bok.setFont(f1);
        bok.addActionListener(this);
                
        bexit=new JButton("Exit");
        bexit.setToolTipText("USED TO EXIT FROM SYSTEM");
        bexit.setFont(f1);
        bexit.addActionListener(this);
                
 		img = new ImageIcon("logo2.jpg");
		lbl = new JLabel(img);           
            
        cnt=0;
                
        p1=new JPanel(); 
        p1.setBorder(new LineBorder(new Color(198,100,100), 4, true));
        p1.setBounds(300,200,400,300);

		p2=new JPanel();  
		p2.setBorder(new LineBorder(new Color(198,100, 100), 4, true));
        p2.setBounds(300,200,400,300);
		    
		p3=new JPanel();
		p3.setBorder(new LineBorder(new Color(198,100, 100), 4, true));
        p3.setBounds(300,200,400,300);
            
        p1.setLayout(new FlowLayout());
        p2.setLayout(new FlowLayout());
        p3.setLayout(new FlowLayout());
                                
        p1.add(l1);
        p2.add(l2); 
        p2.add(t1);
        p2.add(l3); 
        p2.add(t2);
        p2.add(lbl); 
        p3.add(bok);
        p3.add(bexit);
                
        cp.add(p1,BorderLayout.NORTH);
        cp.add(p2,BorderLayout.CENTER);
        cp.add(p3,BorderLayout.SOUTH);
                
        setBounds(0,0,1024,748);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
			
    } //constr
    public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==bexit)
        {
        	int r=JOptionPane.showConfirmDialog(null,"Do You Want To Exit ?","THANK YOU",JOptionPane.YES_NO_OPTION);
			if(r==JOptionPane.YES_OPTION)
        	System.exit(0);
        }
        else if(ae.getSource()==bok)
        {
        	String s1=t1.getText();
            String s2=t2.getText();
            if(s1.equals(" SHAAN CARS Pvt. Ltd. "))
            {
            	if(s2.equals("prashant22"))
                {
                	{
                    	dispose();
                       	homepage hp=new homepage();      //NEW SCREEN CALL
                    }
                    cnt=0;
                }
                else
                {
                     cnt++;
                     mydialog m1 = new mydialog(this , "INCURRECT PASSWORD !");
                     m1.setVisible(true);
            	}
            }
            else
            {
             	cnt++;
                mydialog m2 = new mydialog(this ," INCURRECT USERNAME !");
                m2.setVisible(true);
            }
   			if(cnt==4)
            {
            	System.exit(0);
            }
    
      }
}
class mydialog extends Dialog implements ActionListener
{  
	mydialog(Frame parent , String title)
   {   
   	   super(parent , title);
       setLayout(new BorderLayout());
       setBounds(350,250,250,200);
       setFont(new Font("Dialog" , Font.PLAIN , 20)); 
       JLabel L1 = new JLabel("       SORRY , INCURRECT LOGIN !");
       JButton B1 = new JButton("Cancel");
       B1.addActionListener(this);
       add(L1,BorderLayout.CENTER);      add(B1,BorderLayout.SOUTH);
   } 
 	public void actionPerformed(ActionEvent ae)
   {   
   dispose();
   }
}	

public static void main(String arg[])
    {
        new dialog();
    }
}
                


