import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.sql.*;

class carinfo1 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	JButton b1,b2,b3,b4; 
	Container c;
	JPanel p1,p2,p3,p4;
	JComboBox color,whl;
	ResultSet rs;
	Connection cn;
	Statement st;
	Font f1,f2,f3;
	Checkbox chk1,chk2, chk3,chk4,chk5,chk6,chk7,chk8,chk9,chk10,chk11,chk12,chk13;
	CheckboxGroup cbg1;
	carinfo1()
	{
		super("Car Information Form");
		c=getContentPane();
		c.setLayout(new BorderLayout());
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex)
		{
			System.out.println(ex);
            }
		CheckboxGroup cbg1=new CheckboxGroup();
		f1=new Font("Times New Roman",Font.BOLD,15);
        f2=new Font("Times New Roman",Font.BOLD,45);
      		
        l1=new JLabel("SHAAN CARS Pvt. Ltd.");
		l1.setFont(f2);
        l1.setForeground(Color.red);
		
		l2=new JLabel("SELECT CAR NAME");
		l2.setFont(f1);
        
	
		l3=new JLabel("  AVERAGE ");
		l3.setFont(f1);
        
	    l4=new JLabel("  LENGTH ");
		l4.setFont(f1);
       
		l5=new JLabel("  HEIGHT ");
		l5.setFont(f1);
		
		l6=new JLabel("  WIDTH ");
		l6.setFont(f1);
		
		l17=new JLabel("  WHEELS ");
		l17.setFont(f1);
        
        l7=new JLabel("  TURNING RADIOUS ");
		l7.setFont(f1);
        
		l8=new JLabel("  ENGINE ");
		l8.setFont(f1);
       
		l9=new JLabel("  FUEL CAPACITY ");
		l9.setFont(f1);
        
        l10=new JLabel("  POWER ");
		l10.setFont(f1);
       
		l11=new JLabel("  SEATING CAPACITY ");
		l11.setFont(f1);
		
		l12=new JLabel("  NO. OF CYLINDERS WITH VOLVES ");
		l12.setFont(f1);
      
		l13=new JLabel("  AVAILABLE COLOUR ");
		l13.setFont(f1);
       
        l14=new JLabel("  EX-SHOWROOM PRICE : ");
		l14.setFont(f1);
		
		l15=new JLabel("     1. WITH LBT :");
		l15.setFont(f1);
		
		l16=new JLabel("     2. WITHOUT LBT :");
		l16.setFont(f1);
		
		t1=new JTextField(5);
		t1.setFont(f1);
        
		t2=new JTextField(5);
		t2.setFont(f1);
      
		t3=new JTextField(5);		
		t3.setFont(f1);
       
		
		t4=new JTextField(5);
		t4.setFont(f1);
//        t4.setForeground(Color.black);
		
		t5=new JTextField(5);
		t5.setFont(f1);
   
   		t6=new JTextField(5);
		t6.setFont(f1);
        
        t7=new JTextField(5);
		t7.setFont(f1);
      
		t8=new JTextField(5);
		t8.setFont(f1);
		
		t9=new JTextField(5);
		t9.setFont(f1);
		
		t10=new JTextField(5);
		t10.setFont(f1);
		
		t11=new JTextField(5);
		t11.setFont(f1);
		
		t12=new JTextField(5);
		t12.setFont(f1);
		
		color=new JComboBox();
		whl=new JComboBox();
		
        color.addItem(" *  Midnight Black");
        color.addItem(" *  Blue Blaze");
        color.addItem(" *  Silky Silver");
		color.addItem(" *  Superior White");
		color.addItem(" *  Bright Red");
		color.addItem(" *  Glistening Grey");
		
        whl.addItem(" *  MackWheels ");
        whl.addItem(" *  AlloyWheels ");
        
        chk1= new Checkbox("Maruti 800", false , cbg1);
        chk2= new Checkbox("Maruti OMNI", false , cbg1);
        chk3= new Checkbox("ALTO", false , cbg1);
        chk4= new Checkbox("ALTO 800", false , cbg1);
        chk5= new Checkbox("Eeco", false , cbg1);
        chk6= new Checkbox("WagonR", false , cbg1);
        chk7= new Checkbox("WagonR Duo", false , cbg1);
        chk8= new Checkbox("Ritz", false , cbg1);
        chk9= new Checkbox("Swift", false , cbg1);
        chk10= new Checkbox("Swift Desire", false , cbg1);
        chk11= new Checkbox("SX4", false , cbg1);
        chk12= new Checkbox("Ertiga", false , cbg1);
		chk13= new Checkbox("Grand Vitara", false , cbg1);

        b1=new JButton("HOME");
		b1.setFont(f1);
		b1.addActionListener(this);
		
		b2=new JButton("CLEAR");
		b2.setFont(f1);
		b2.addActionListener(this);
		
		b3=new JButton("NEXT");
		b3.setFont(f1);
		b3.addActionListener(this);
		
		b4=new JButton("SHOW");
		b4.setFont(f1);
		b4.addActionListener(this);
		
		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
        p1.setLayout(new FlowLayout());
        
		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
        p2.setLayout(new GridLayout(15,2));
       
		p3=new JPanel();
		p3.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
        p3.setBounds(300,200,400,300);
		
		p4=new JPanel();
		p4.setBorder(new LineBorder(new Color(198, 100, 100), 3, true));
        p4.setLayout(new GridLayout(15,2));

        p1.add(l1);
      
       	p4.add(l2);		
		p4.add(chk1);p4.add(chk2);p4.add(chk3);p4.add(chk4);p4.add(chk5);p4.add(chk6);
		p4.add(chk7);p4.add(chk8);p4.add(chk9);p4.add(chk10);p4.add(chk11);p4.add(chk12);p4.add(chk13);
			
		p2.add(l3);		
		p2.add(t1);
		p2.add(l17);		
		p2.add(whl);
		p2.add(l4);		
		p2.add(t2);
    	p2.add(l5);		
		p2.add(t3);
		p2.add(l6);		
		p2.add(t4);
		p2.add(l7);
		p2.add(t5);
		p2.add(l8);
		p2.add(t6);
		p2.add(l9);
		p2.add(t7);
		p2.add(l10);
		p2.add(t8);
		p2.add(l11);
		p2.add(t9);
		p2.add(l12);
		p2.add(t10);
		p2.add(l13);
		p2.add(color);
		p2.add(l14);
		p2.add(new JLabel(""));
		p2.add(l15);
		p2.add(t11);
		p2.add(l16);
		p2.add(t12);

		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
	
		c.add(p1,BorderLayout.NORTH);
		c.add(p2,BorderLayout.CENTER);
//		c.add(p5);//,BorderLayout.EAST);
		c.add(p3,BorderLayout.SOUTH);
		c.add(p4,BorderLayout.WEST);

	    setBounds(130,100,800,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)	
	{
		if(ae.getSource()==b1)
		{
			dispose();
			homepage hp=new homepage(); 	
		}
		if(ae.getSource()==b2)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			t8.setText("");
			t9.setText("");
			t10.setText("");
			t11.setText("");
			t12.setText("");
		}
		if(ae.getSource()==b3)
		{
			dispose();
			custinfo ci=new custinfo();
        }
        if(ae.getSource() == b4)
        {  
        	if(chk1.getState()==true)
            {
            try
   		    	{
   		        	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
                    //JOptionPane.showMessageDialog(null,"CONNECTION SUCESSFULL","MSG",JOptionPane.INFORMATION_MESSAGE);
					st = cn.createStatement();				
                    rs = st.executeQuery("select * from carinfo1 where Carname ='"+chk1.getLabel()+"'"); 
					disp();
               	}
               	catch(Exception e)	
		       	{ }
			} 	
			else if(chk2.getState() == true)
        	{
            	try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname ='"+chk2.getLabel()+"'");	
					disp();
               	}   
		   	  	catch(Exception e)	
		      	{ }
		 	}  		
		 	else if(chk3.getState() == true)
         	{
            	try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk3.getLabel()+"'");	
					disp();
               	}   
		       	catch(Exception e)	
		       	{ }
		 	}  		
		 	else if(chk4.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk4.getLabel()+"'");	
					disp();
               	}   
		       	catch(Exception e)	
		       	{ }
		 	}  		
		 	else if(chk5.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk5.getLabel()+"'");	
					disp();
               	}   
		      	catch(Exception e)	
		       	{ }
		 	}  		
		 	else if(chk6.getState() == true)
         	{ 
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk6.getLabel()+"'");	
					disp();
              	}   
		        catch(Exception e)	
		        { }
		 	}  		
		 	else if(chk7.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk7.getLabel()+"'");	
					disp();
              	}   
		        catch(Exception e)	
		        { }
		 	}  		
		 	else if(chk8.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk8.getLabel()+"'");	
					disp();
		       }   
		       catch(Exception e)	
		 	   { }
		 	}  		
		 	else if(chk9.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk9.getLabel()+"'");	
					disp();
              	}   
		        catch(Exception e)	
		        { }
		 	}  		
		 	else if(chk10.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs= st.executeQuery("select * from carinfo1 where Carname = '"+chk10.getLabel()+"'");	
					disp();
				}
         		catch(Exception e)
         		{ }			
         	} 
	     	else if(chk11.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk11.getLabel()+"'");	
		     		disp();
              	} 
              	catch(Exception e)
              	{ }	  
	   		}
	   		else if(chk12.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk12.getLabel()+"'");	
		     		disp();
              	} 
              	catch(Exception e)
              	{ }	  
	   		}
	   		else if(chk13.getState() == true)
         	{
                try
   		        {
   					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					cn = DriverManager.getConnection("jdbc:odbc:tybsc1");
					st = cn.createStatement();				
	    			rs = st.executeQuery("select * from carinfo1 where Carname = '"+chk13.getLabel()+"'");	
		     		disp();
              	} 
              	catch(Exception e)
              	{ }	  
	   		}
	   		else
	   		{
		 		JOptionPane.showMessageDialog(null,"Please Choose Car Name","Error",JOptionPane.ERROR_MESSAGE);
	   		}
     	}
  	}
    public void disp()
    {
    	try
     	{
     		while(rs.next())
            {
        		t1.setText(rs.getString(3));	//t1.setText(" A ");
				t2.setText(rs.getString(4));	//t2.setText(" B ");
				t3.setText(rs.getString(5));	//t3.setText(" C ");
				t4.setText(rs.getString(6));	//t4.setText(" D ");
				t5.setText(rs.getString(7));	//t5.setText(" E ");
				t6.setText(rs.getString(8));	//t6.setText(" F ");
				t7.setText(rs.getString(9));	//t7.setText(" G ");
				t8.setText(rs.getString(10));	//t8.setText(" H ");
				t9.setText(rs.getString(11));	//t9.setText(" I ");
				t10.setText(rs.getString(12));	//t10.setText(" J ");
			  	t11.setText(""+rs.getDouble(13));
			  	t12.setText(""+rs.getDouble(14));
		    	break;
		    }
		    rs.close();
			st.close();
			cn.close();
		}
		catch(Exception e)
		{ }
	}	          
    public static void main(String arg[])
    {
    	new carinfo1();
    }
}