import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import java.util.*;
import java.text.*;
class carinforeport extends JFrame implements WindowListener, ActionListener
{
	int count=0;
	Connection con;
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	JLabel j1;
	JButton cprint=new JButton("PRINT");
	JButton chome=new JButton("BACK");
	Font f=new Font("Times New Roman",Font.BOLD,16);
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	Font h1=new Font("Wide Latin",Font.BOLD,22);
	carinforeport()
	{
		super(" Car Information ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Container c=getContentPane();
		JLabel d1=new JLabel(" SHAAN Cars Pvt. Ltd. ");
		d1.setBounds(270,30,500,30);
	   	d1.setFont(h1);
	   	add(d1);
		JLabel h2=new JLabel(" Car Information ");
	  	h2.setBounds(300,50,500,30);
	   	h2.setFont(h1);
	   	add(h2);
	   	c.add(p1);
		c.add(p2);
		setSize(1030,580);
		setLocation(-2,100);
		cprint.addActionListener(this);
		chome.addActionListener(this);
		cprint.setFont(f);
		chome.setFont(f);
		p2.add(cprint);
		p2.add(chome);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			st =con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			p1.setBounds(0,130,1024,350);
			p2.setBounds(0,648,0,0);
			p1.setBackground(new Color(198,100,100));
			p2.setBackground(new Color(198,100,100));
			p1.setLayout(new BorderLayout());
			p2.setLayout(null);
			cprint.setBounds(400,500,100,30);
			chome.setBounds(550,500,90,30);
			cprint.setToolTipText("This Button Prints Document");
			chome.setToolTipText("This Button Goes to the Main Screen");
			String[] colHeads={"Car Name","Average","LENGTH","WIDTH","HEIGHT","Turning Radius","Engine","Fuel Capacity","Power","Seating Capacity","Cylinders With Volves","Ex-Showroom Price With LBT","Ex-Showroom Price Without LBT"};
			rs = st.executeQuery("select * from carinfo1");
			while (rs.next())
				count++;
			Object[][] results=new Object[count][15];
			rs.first();
			for(int i=0;i<count;i++)
			{
				results[i][0]=rs.getString(1);
				results[i][1]=rs.getString(2);
				results[i][2]=rs.getString(3);
				results[i][3]=rs.getString(4);
				results[i][4]=rs.getString(5);
				results[i][5]=rs.getString(6);
				results[i][6]=rs.getString(7);
				results[i][7]=rs.getString(8);
				results[i][8]=rs.getString(9);
				results[i][9]=rs.getString(10);
				results[i][10]=rs.getString(11);
				results[i][11]=rs.getString(12);
				results[i][12]=rs.getString(13);
				results[i][13]=rs.getString(14);
				rs.next();
			}
			JTable table=new JTable(results,colHeads);
			int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
			int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
			JScrollPane jsp=new JScrollPane(table,v,h);
			p1.add(jsp,BorderLayout.CENTER);
		}
		catch(Exception e)
		{
			String dt=" ERROR";
			String dm=" ERROR : "+e;
			int dtype=JOptionPane.ERROR_MESSAGE;
			JOptionPane.showMessageDialog((Component)null, dm, dt, dtype);
		}
		setVisible(true);
		c.setBackground(new Color(168,81,255));
		addWindowListener(this);
	}
	public static void main(String args[])
	{
		new carinforeport();
	}
	public void actionPerformed(ActionEvent a)
	{
		String s=a.getActionCommand();
		if(s.equals("BACK"))
		{
			dispose();
			report rp=new report();
		}
		else
		if(s.equals("PRINT"))
		{
			PrintUtilities.printComponent(this);
		}
	}
	public void windowClosing(WindowEvent w)
	{
		setVisible(false);
	}
	public void windowClosed(WindowEvent w){}
	public void windowOpened(WindowEvent w){}
	public void windowActivated(WindowEvent w){}
	public void windowDeactivated(WindowEvent w){}
	public void windowIconified(WindowEvent w){}
	public void windowDeiconified(WindowEvent w){}
}