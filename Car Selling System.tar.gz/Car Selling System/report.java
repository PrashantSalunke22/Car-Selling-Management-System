import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
class report extends JFrame implements ActionListener
{
	JButton bhome,bcustform,bcarinfo,bpayinfo,bqty,bexit;
	JLabel l1,l2;
	JPanel p1,p2,p3,p4,p5;
	ImageIcon ic1=new ImageIcon("BMW-M1.jpg");
	ImageIcon ic2=new ImageIcon("Peugeot.jpg");
	Container cp;
	Font f1,f2,f3;
	report()  //constr
	{
		super("Report Page");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		f1=new Font("Times New Roman",Font.BOLD,20);
		f2=new Font("Times New Roman",Font.BOLD,45);
		f3=new Font("Times New Roman",Font.BOLD,10);

		l1=new JLabel("SHAAN Cars Pvt. Ltd.| E-3,MIDC Area,Satpur,Nashik 422007 | Ph: 0253-2351279 ");
		l1.setFont(new Font("Times New Roman",Font.BOLD,15));
		l1.setForeground(Color.red);

		bcarinfo=new JButton("Car_Info Report");
		bcarinfo.setFont(f1);
		bcarinfo.addActionListener(this);
		bcarinfo.setToolTipText("SEE YOUR CAR INFORMATION");

		bcustform=new JButton("Cust_Form Report");
		bcustform.setFont(f1);
		bcustform.addActionListener(this);
		bcustform.setToolTipText("SEE CUSTOMER INFORMATION");

		bpayinfo=new JButton("PaymentInfo Report");
		bpayinfo.setFont(f1);
		bpayinfo.addActionListener(this);
		bpayinfo.setToolTipText("SEE PAYMENT INFORMATION");

		bqty=new JButton("Car Quantity Report");
		bqty.setFont(f1);
		bqty.addActionListener(this);
		bqty.setToolTipText("SEE Car Quantity Report");

		bexit=new JButton("Exit");
		bexit.setFont(f1);
		bexit.addActionListener(this);
		bexit.setToolTipText("Exit The System");

		bhome=new JButton("Home");
		bhome.setFont(f1);
		bhome.addActionListener(this);
		bhome.setToolTipText("Go To Home");

		JLabel im1=new JLabel("",ic1,JLabel.RIGHT);
		im1.setSize(320,480);
		
		JLabel im2=new JLabel("",ic2,JLabel.LEFT);
		im2.setSize(240,320);
		
		l2=new JLabel("� 2013_2014 Vin All rights reserved.");
		l2.setBounds(20,475,500,25); 
		l2.setFont(f3);
		l2.setForeground(Color.blue);

		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p3=new JPanel();
		p3.setBorder(new LineBorder(Color.white,4,true));

		p4=new JPanel();
		p4.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p5=new JPanel();
		p5.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p1.setLayout(new FlowLayout());
		p2.setLayout(new GridLayout(5,1));
		p3.setLayout(new GridLayout(2,1));
		p4.setLayout(new GridLayout(5,1));
		p5.setLayout(new FlowLayout());

		p1.add(l1);

		p2.add(bcarinfo);
		p2.add(new JLabel(""));
        p2.add(bcustform);
        p2.add(new JLabel(""));
        p2.add(bpayinfo);
        
        p3.add(im1);
        p3.add(im2);
        
        p4.add(bhome);
        p4.add(new JLabel(""));
        p4.add(bqty);
        p4.add(new JLabel(""));
        p4.add(bexit);
		                        
        p5.add(l2); 

        add(p1,BorderLayout.NORTH);
        add(p2,BorderLayout.EAST);
        add(p3,BorderLayout.CENTER);
        add(p4,BorderLayout.WEST);
        add(p5,BorderLayout.SOUTH);

        setBounds(190,100,700,650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setVisible(true);
	} //end of constr
    public void actionPerformed(ActionEvent ae)
    {
      	if(ae.getSource()==bhome)
	   	{
			dispose();
        	homepage h=new homepage();
        }
        if(ae.getSource()==bcarinfo)
        {
        	dispose();
	        carinforeport bi=new carinforeport(); 
        }
        if(ae.getSource()==bcustform)
        {
        	dispose();
        	custinforeport ci=new custinforeport();
        }
		if(ae.getSource()==bqty)
        {
        	dispose();
        	qtyinforeport bi=new qtyinforeport();
        }
        if(ae.getSource()==bpayinfo)
		{
        	dispose();
        	payinforeport pi=new payinforeport(); 
        }
        if(ae.getSource()==bexit)
		{
			System.exit(0);
        }
    }
	public static void main(String args[])
    {
       report rp = new report();
    }
}