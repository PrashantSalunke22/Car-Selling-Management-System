import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.io.*;

public class Login1
{
	public static void main(String args[])
	{
		LScreen ls=new LScreen();
		ls.createScreen();
	}
}

class LScreen implements ActionListener
{
	JFrame lfrm;
	JButton login;
	JLabel ScreenLabel;
	JLabel uname;
	JTextField un;
	JLabel pwd;
	JTextField passwd;
	Font f1=new Font("Comic Sans MS",Font.BOLD,14);
	
	void createScreen()
	{
	lfrm=new JFrame("Login Screen");
	lfrm.setLayout(null);
	
	ImageIcon icon=new ImageIcon("Ertiga.png");
	lfrm.setIconImage(icon.getImage());
	
	lfrm.setSize(500,500);
	lfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	ScreenLabel=new JLabel("Sign In");
	ScreenLabel.setBounds(130,5,290,70);
	ScreenLabel.setFont(new Font("Cooper Black",Font.PLAIN,20));
	
	uname=new JLabel("User Name:");
	uname.setBounds(20,50,90,70);
	uname.setFont(new Font("Comic Sans MS",Font.BOLD,15));
	un=new JTextField();
	un.setBounds(130,70,290,30);
	
	pwd=new JLabel("Password:");
	pwd.setBounds(20,100,90,100);
	pwd.setFont(new Font("Comic Sans MS",Font.BOLD,15));
	passwd=new JPasswordField();
	passwd.setBounds(130,135,290,30);
	
	login=new JButton("Login");
	login.setFont(f1);
	login.setBounds(130,190,80,30);
	login.addActionListener(this);
	
	lfrm.add(uname);
	lfrm.add(un);
	lfrm.add(pwd);
	lfrm.add(login);
	lfrm.add(passwd);
	lfrm.add(ScreenLabel);
    
	lfrm.setVisible(true);

	}
	
	public void actionPerformed(ActionEvent e)
	{
		
	   	if(e.getSource()==login)
	   	    {
	   	    	String login=un.getText();
	   	    	String pass=passwd.getText();
	   	    if(login.equals("SHAAN")&&pass.equals("shaancar"))
	   	      {
	   	    	JOptionPane.showMessageDialog(null,"Login Sucsessfully Done..","Welcome",JOptionPane.INFORMATION_MESSAGE);
	  			// MainScreen ms=new MainScreen();
	   	    	System.out.println("Login Successfully");  
	   	    	 // ms.setVisible(true);
	   	    	 lfrm.dispose();
	//		w.setVisible(true);
			}else
			{
				JOptionPane.showMessageDialog(null,"Login Unsuccessful. ID and Password!","alert..",JOptionPane.INFORMATION_MESSAGE);
	  			
			}
	
	}
}
}