import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;

public class Welcome extends JFrame 
{
	public Welcome()
	{
		ImageIcon ic=new ImageIcon("Welcome22.jpg");
		JLabel jl=new JLabel(ic);
		add(jl);		
		setLayout(null);
		jl.setLocation(0,0);
		jl.setSize(960,720);
		setUndecorated(true);
		setLocation(30,5);
		setSize(960,720);
		setVisible(true);
		new progressbar();
	}	
	public static void main(String args[])
	{
		new Welcome();
	}
}