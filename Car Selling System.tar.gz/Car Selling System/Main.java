import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public class Main 
{
	public static void main(String args[])
	{
    		JButton button = new JButton("foo");
    		JTextField textField = new JTextField(10);
    		Document document = textField.getDocument();
    		document.addDocumentListener(new JButtonStateController(button));
  	
  		  	JFrame frame = new JFrame();
    		frame.add(button,BorderLayout.WEST);
    		frame.add(textField,BorderLayout.CENTER);
    		frame.setSize(300,300);
    		frame.setVisible(true);
  	}

}
class JButtonStateController implements DocumentListener 
{
	JButton button;
  
  	JButtonStateController(JButton button) 
  	{
    	this.button = button ;
	}

  	public void changedUpdate(DocumentEvent e) 
  	{
    	disableIfEmpty(e);
  	}

  	public void insertUpdate(DocumentEvent e) 
  	{
    	disableIfEmpty(e);
  	}

  	public void removeUpdate(DocumentEvent e) 
  	{
    	disableIfEmpty(e);
  	}

  	public void disableIfEmpty(DocumentEvent e) 
  	{
    	button.setEnabled(e.getDocument().getLength() > 0);
  	}
}