import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.io.*;
import java.sql.*;

class billinfo extends JFrame implements ActionListener
{

	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,addrs,phlabel;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JButton b1,b2,b3,b4,b5,b6; 
	Container cp;
	JPanel p1,p2,p3,p4,p5;
	JComboBox color = new JComboBox();
    JComboBox pay = new JComboBox();
    JComboBox car = new JComboBox();
	Font f1,f2;
	int updateenqno = 0;
		
	billinfo()
	{
		super("Bill Form");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		
		try
            {
               UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            }
            catch(Exception ex)
            {
               System.out.println(ex);
            }
		f1=new Font("Times New Roman",Font.BOLD,15);
        f2=new Font("Times New Roman",Font.BOLD,25);
        
		l1=new JLabel(" SHAAN CARS Pvt. Ltd. ");
		l1.setFont(new Font("Times New Roman",Font.ITALIC,30));
        l1.setForeground(Color.red);
		
		JLabel addrs=new JLabel(" E-3,MIDC Area,Satpur,Nashik 422007 | Ph: 0253-2351279 ");
		addrs.setFont(new Font("Times New Roman",Font.BOLD,15));
        addrs.setForeground(Color.black);
		
		l2=new JLabel(" Bill NO :");
		l2.setFont(f1);
        l2.setForeground(Color.black);
		
		t1=new JTextField(8);
		t1.setFont(f1);
        t1.setForeground(Color.red);
		
		l3=new JLabel(" Date :");
		l3.setFont(f1);
        l3.setForeground(Color.black);
	
		t2=new JTextField(10);
		t2.setFont(f1);
		t2.setForeground(Color.red);
		
		l4=new JLabel("\t CUSTOMER NAME");
		l4.setFont(f1);
        l4.setForeground(Color.black);
		
		t3=new JTextField(5);
		t3.setFont(f1);
        t3.setForeground(Color.black);
		
		l5=new JLabel("\t ADDRESS (TEMP)");
		l5.setFont(f1);
        l5.setForeground(Color.black);
		
		t4=new JTextField(5);		
		t4.setFont(f1);
        t4.setForeground(Color.black);
		
		l6=new JLabel("\t ADDRESS (PERM)");
		l6.setFont(f1);
        l6.setForeground(Color.black);
		
		t5=new JTextField(5);
		t5.setFont(f1);
        t5.setForeground(Color.black);
		
		l7=new JLabel("\t CAR");
		l7.setFont(f1);
        l7.setForeground(Color.black);
		
		l8=new JLabel("\t COLOUR");
		l8.setFont(f1);
        l8.setForeground(Color.black);
		
		l9=new JLabel("\t CHESIS NO :");
		l9.setFont(f1);
        l9.setForeground(Color.black);

        t6=new JTextField(5);
		t6.setFont(f1);
        t6.setForeground(Color.black);
       
        l10=new JLabel("\t ENGINE NO :");
		l10.setFont(f1);
        l10.setForeground(Color.black);
		
		t7=new JTextField(5);
		t7.setFont(f1);
        t7.setForeground(Color.black);
       
		l11=new JLabel("\t PAYMENT BY ");
		l11.setFont(f1);
        l11.setForeground(Color.black);
		
		l12=new JLabel("\t TOTAL AMOUNT ");
		l12.setFont(f1);
        l12.setForeground(Color.black);
		
		t8=new JTextField(5);
		t8.setFont(f1);
        t8.setForeground(Color.black);
       
		b1=new JButton("HOME");
		b1.setFont(f1);
		b1.addActionListener(this);
		
		b2=new JButton("BACK");
		b2.setFont(f1);
		b2.addActionListener(this);
		
		b3=new JButton("CLEAR");
		b3.setFont(f1);
		b3.addActionListener(this);
		
		b4=new JButton("SAVE");
		b4.setFont(f1);
		b4.addActionListener(this);
		
		b5=new JButton("UPDATE");
		b5.setFont(f1);
		b5.addActionListener(this);

		b6=new JButton("SEARCH");
		b6.setFont(f1);
		b6.addActionListener(this);
		
		pay.addItem("CASH");
        pay.addItem("CHEQUE");

        color.addItem(" * Midnight Black");
		color.addItem(" * Blue Blaze");
        color.addItem(" * Silky Silver");
		color.addItem(" * Superior White");
		color.addItem(" * Bright Red");
		color.addItem(" * Glistening Grey");
		
        car.addItem("Maruti 800");
        car.addItem("Maruti OMNI");
        car.addItem("ALTO");
        car.addItem("ALTO 800");
        car.addItem("Eeco");
        car.addItem("WagonR");
        car.addItem("WagonR Duo");
        car.addItem("Ritz");
        car.addItem("Swift");
        car.addItem("Swift Desire");
        car.addItem("SX4");
        car.addItem("Ertiga");
        car.addItem("Grand Vitara");
		
		p1=new JPanel();
		p1.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p2=new JPanel();
		p2.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
		
		p3=new JPanel();
		p3.setBorder(new LineBorder(new Color(198, 100, 100), 4, true));
			
		p1.setLayout(new FlowLayout());
        p2.setLayout(new GridLayout(12,2));
        p3.setLayout(new FlowLayout());
   
        p1.add(l1);
        p1.add(addrs);
      	
        p2.add(l2);      
		p2.add(t1);
 		
		p2.add(l3);
		p2.add(t2);
		
		p2.add(l4);		
		p2.add(t3); 
		
		p2.add(l5);		
		p2.add(t4);
		
		p2.add(l6);		
		p2.add(t5);
		
		p2.add(l7);
		p2.add(car);
		
		p2.add(l8);
		p2.add(color);
		
		p2.add(l9);
		p2.add(t6);
		
		p2.add(l10);
		p2.add(t7);
		
		p2.add(l11);
		p2.add(pay);
		
		p2.add(l12);
		p2.add(t8);
		
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		p3.add(b5);		
		p3.add(b6);
	
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p2,BorderLayout.CENTER);
		cp.add(p3,BorderLayout.SOUTH);

        setBounds(130,100,800,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	
}
	public void do_update()
	{
		Connection con;
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from billinfo");
			while(rs.next())
			{
				updateenqno = rs.getInt(1);				
			}
			updateenqno = updateenqno +1;
	    }
	    catch (SQLException se) 
	    {
	    	System.out.println ("Ex1:"+se);
	    }
	    catch (Exception eg) 
	    {
	    	System.out.println ("Ex2:"+eg);
	    }
	}
	public void actionPerformed(ActionEvent ae)	
	{
			
		String str = ae.getActionCommand();
	    Connection con ;
	    Statement stat ;
			if(ae.getSource()==b1)
		{
			dispose();
			homepage hp=new homepage();
		}
		if(ae.getSource()==b2)
		{
		 	dispose();
		 	custinfo bi=new custinfo();
		}
		
		if(ae.getSource()==b3)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			t8.setText("");
		}
		if(ae.getSource()==b4)
		{
			do_update();
			int intinsert=0;
		    Boolean flag = false;
		    if(t1.getText().equals("")||t2.getText().equals("")||t3.getText().equals("")||t4.getText().equals("")||
		    t5.getText().equals("")||t6.getText().equals("")||t7.getText().equals("")||t8.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please Fill All The Information","Error",JOptionPane.ERROR_MESSAGE);
				
			}
			try 
			{			
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con = DriverManager.getConnection("jdbc:odbc:tybsc1");
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from billinfo");
			        
			       while(rs.next())
				{
					if(rs.getInt(1) == Integer.parseInt(t1.getText()))
					{
						flag = true;
					}
				}
				if(flag == false)
				{
				
	
				PreparedStatement pstmt = con.prepareStatement("insert into billinfo values (?,?,?,?,?,?,?,?,?,?,?)");
					
					
			    	pstmt.setInt(1,Integer.parseInt(t1.getText()));
			    	pstmt.setString(3,t2.getText());
			    	pstmt.setString(2,t3.getText());
			    	pstmt.setString(4,t4.getText());
			    	pstmt.setString(5,t5.getText());
			    	pstmt.setString(6,""+car.getSelectedItem());
			    	pstmt.setString(7,""+color.getSelectedItem());
			    	pstmt.setString(8,t6.getText());
			    	pstmt.setString(9,t7.getText());
			    	pstmt.setString(10,""+pay.getSelectedItem());
			    	pstmt.setDouble(11,Double.parseDouble(t8.getText()));
			    	intinsert=pstmt.executeUpdate();
			    	pstmt.close();
			    	con.close();
				}
				if(flag == true)
				{
					JOptionPane.showMessageDialog(null,"Bill No Already Exists","Error",JOptionPane.ERROR_MESSAGE);
					t1.setText(null);
				}
			}
		    catch (SQLException e4) 
		    {
		    }
		    catch (Exception ex3) 
		    {
		    	
		    }
		    if(intinsert == 1)
		    {
		    	JOptionPane.showMessageDialog(null,"Record Save Successfully");
		    	t1.setText(null);
		    	t2.setText(null);
		    	t3.setText(null);
		    	t4.setText(null);
		    	t5.setText(null);
		    	t6.setText(null);
		    	t7.setText(null);
		    	t8.setText(null);
		    		    	
		    }
        }
	if(ae.getSource()==b6)
	{
		if(t1.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please enter the bill number","Error",JOptionPane.ERROR_MESSAGE);
				
			}
			try 
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con = DriverManager.getConnection("jdbc:odbc:tybsc1");
				System.out.println ("Got Connection :"+con);
				stat = con.createStatement();
				
			    ResultSet rs = stat.executeQuery("select * from billinfo");
			    while(rs.next())
			    {     
			    	
			    	if(rs.getInt(1) == Integer.parseInt(t1.getText()))
			    	{
			    			
			    		
			    		t2.setText(rs.getString(3));
			    		t3.setText(rs.getString(2));		    		
			    		t4.setText(rs.getString(4));			    		
			    		t5.setText(rs.getString(5));			    		
			    		t6.setText(rs.getString(8));
			    		t7.setText(rs.getString(9));
			    		t8.setText(rs.getString(11));    		
			    		color.setSelectedItem(String.valueOf(rs.getString(7)));
			    		pay.setSelectedItem(String.valueOf(rs.getString(10)));    		
			    		car.setSelectedItem(String.valueOf(rs.getString(6)));
			    	}
			    }			    
			    con.close();
			    stat.close();			    
			 }  
			catch (SQLException e7) 
		    {
		    	JOptionPane.showMessageDialog(null,"Record Not Found","Error",JOptionPane.ERROR_MESSAGE);
		    	    t1.setText(null);
			    	t2.setText(null);
			    	t3.setText(null);
			    	t4.setText(null);
			    	t5.setText(null);
			    	t6.setText(null);
			    	t7.setText(null);
			    	t8.setText(null);
		    }
		    catch (Exception ex5) 
		    {
		    	
		    }
	}
  }
    public static void main(String arg[])
    {
    	billinfo bi=new billinfo();
    }
}