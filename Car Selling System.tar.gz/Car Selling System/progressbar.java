import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
class progressbar extends JFrame implements Runnable
{
	Thread t=new Thread(this);
	JFrame frm;
	JProgressBar br;
	int val=0;
	JLabel loading;
	JPanel pn=new JPanel();
	progressbar()
	{
		frm=new JFrame("Process is running...");
		setBounds(220,690,1000,30);
		setUndecorated(true);
		add(pn);
		pn.setLayout(null);
		//-------------------Providing border--------------------
		Border bd=BorderFactory.createTitledBorder("INITIALIZING");
		pn.setBorder(bd);
		//-------------------Heading (label)---------------------
		loading=new JLabel("Loading.....");
		loading.setBounds(10,50,200,40);
		loading.setFont(new Font("Dialog",Font.BOLD,13));
		loading.setForeground(Color.RED);
		pn.add(loading);
		//-------------------Adding progress bar------------------
		br=new JProgressBar();
		br.setBounds(220,290,870,30);
		br.setBackground(Color.GREEN);
		br.setForeground(Color.BLACK);
		br.setBorderPainted(true);
		br.setStringPainted(true);
		br.setValue(val);
		add(br);
		//--------------------Starting thread----------------------
		t.start();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	//------------------------Thread method------------------------
	public void run()
	{
		for(;;)
		{
			br.setValue(val);
			br.setString(val+"%");
			try
			{
				Thread.sleep(20);
				val++;
				if(val==101)
				{
					Thread.sleep(100);
					this.dispose();
					
					new Login();
				}
			}
			catch(Exception e)
			{
				System.out.print("This is exception.");	
			}
		}
	}
	public static void main(String args[])
	{
		new progressbar();
	}
}