function isValidName(name)
{
	var s=name;
	if(s.length>0)
	{
		if(s.length<3)
		{
			return "INVALID";
		}
		
		s=s.toLowerCase();
		i=0;
		while(i<s.length)
		{
			ch=s.charAt(i);
			//alert(ch);
			if(!(ch>='a'&&ch<='z')&& ch!=' ')
			{
				return "INVALID";
			}
			if(ch==' ')
			{
				ch=s.charAt(i-1);
				if(ch==' ')
				{
					return "INVALID";
				}
			}
			i++;
		}
		return "VALID";
	}
	else
	{
		return "EMPTY";
	}
}

function isValidAlphaNum(alphanum)
{
	var s=alphanum;
	if(s.length>0)
	{
		s=s.toLowerCase();
		i=0;
		while(i<s.length)
		{
			ch=s.charAt(i);
			//alert(ch);
			if((ch>='a'&&ch<='z') || (ch>='0'&&ch<='9'))
			{
			}
			else
			{
				return "INVALID";
			}
			i++;
		}
		return "VALID";
	}
	else
	{
		return "EMPTY";
	}
}

function isValidEmail(email)
{
	var s=email.toLowerCase();
	if(s.length>0)
	{
		if(s.length<8)
			return "INVALID";
		
		i=0;
		indexAt=s.indexOf("@");
		lastindexAt=s.lastIndexOf("@");
		lastIndexDot=s.lastIndexOf(".");
		indexUnder=s.lastIndexOf("_");

		if(indexAt==-1 || indexAt<=4)
			return "INVALID";
		if(lastIndexDot==-1)
			return "INVALID";
		if(lastIndexDot==0)
			return "INVALID";		
		if(indexUnder==0)
			return "INVALID";
		if(lastIndexDot<indexAt)
			return "INVALID";	
		if(indexAt==lastIndexDot-1)
			return "INVALID";
		if(lastindexAt!=indexAt)
			return "INVALID";		
		if(lastindexAt==s.length-1)
			return "INVALID";
		if(lastIndexDot==s.length-1)
			return "INVALID";		
		if(indexUnder==s.length-1)
			return "INVALID";

		while(i<s.length)
		{
			ch=s.charAt(i);			
			if(!((ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||ch=='.'||ch=='_'||ch=='@'))
			{
				return "INVALID";
			}
			i++;
		}
		return "VALID";
	}
	else
	{
		return "EMPTY";
	}
}

function isValidAddress(addr)
{
	if(addr.length>0)
	{
		return "VALID";
	}
	else
	{
		return "EMPTY";
	}
}

function isValidDouble(number)
{
	flag=false;
	if(number.length>0)
	{
		i=0;
		while(i<number.length)
		{
			ch=number.charAt(i);
			if(!(ch>='0'&&ch<='9')||(ch=='.'&&flag==true))
			{
				return "INVALID";
			}
			if(ch=='.')
			{
				flag=true;
			}
			i++;
		}
		return "VALID";
		
	}
	else
	{
		return "EMPTY";	
	}
}

function isValidPhone(number)
{
	if(number.length>0)
	{
		if(number.length>6)
		{
			i=0;
			while(i<number.length)
			{
				ch=number.charAt(i);
				if(!(ch>='0'&&ch<='9'))
				{
					return "INVALID";
				}
				i++;
			}
			return "VALID";
		}
		else
		{
			return "INVALID";
		}
	}
	else
	{
		return "EMPTY";
	}
}
function isValidNumber(number)
{
	if(number.length>0)
	{
		i=0;
		while(i<number.length)
		{
			ch=number.charAt(i);
			if(!(ch>='0'&&ch<='9'))
			{
				return "INVALID";
			}
			i++;
		}
		return "VALID";
	}
	else
	{
		return "EMPTY";
	}
}
