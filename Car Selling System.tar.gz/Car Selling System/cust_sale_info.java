import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.border.LineBorder;
import java.sql.*;
class cust_sale_info extends JFrame implements ActionListener
{
	int updateenqno = 0;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,addrs,phlabel;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	JButton b1,b2,b3,b4,b5; 
	Container cp;
	JPanel p1,p2,p3;
	Font f1,f2,f3;
	cust_sale_info()
	{
		super("Customer Information Form");
		cp=getContentPane();
		cp.setLayout(new BorderLayout());
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		f1=new Font("Times New Roman",Font.BOLD,15);
		f2=new Font("Times New Roman",Font.ITALIC,25);
		f3=new Font("Times New Roman",Font.BOLD,10);

		l1=new JLabel("SHAAN CARS Pvt. Ltd.");
		l1.setBounds(150,10,800,30);
		l1.setFont(new Font("Times New Roman",Font.ITALIC,30));
		l1.setForeground(Color.red);

		addrs=new JLabel("E-3,MIDC Area,Satpur,Nashik 422007");
		addrs.setBounds(180,40,1000,20);
		addrs.setFont(new Font("Times New Roman",Font.BOLD,20));
		addrs.setForeground(Color.black);
		
		phlabel=new JLabel("Ph: 0253-2351279");
		phlabel.setBounds(130,70,800,20);
		phlabel.setFont(new Font("Times New Roman",Font.BOLD,20));
		phlabel.setForeground(Color.black);
		
		l2=new JLabel("1:\tCUSTOMER NUMBER");
		l2.setFont(f1);
		l2.setForeground(Color.black);

		t1=new JTextField(5);
		t1.setFont(f1);
		t1.setEditable(false);
		t1.setForeground(Color.black);

		l3=new JLabel("2:\tCUSTOMER NAME");
		l3.setFont(f1);
		l3.setForeground(Color.black);

		t2=new JTextField(5);
		t2.setFont(f1);
		t2.setForeground(Color.black);

		l4=new JLabel("3:\tGENDER");
		l4.setFont(f1);
		l4.setForeground(Color.black);
	
		t3=new JTextField(5);		
		t3.setFont(f1);
		t3.setForeground(Color.black);
	
		l5=new JLabel("4:\tAGE");
		l5.setFont(f1);
		l5.setForeground(Color.black);

		t4=new JTextField(5);
		t4.setFont(f1);
		t4.setForeground(Color.black);
	
		l6=new JLabel("5:\tADDRESS(TEMP)");
		l6.setFont(f1);
		l6.setForeground(Color.black);

		t5=new JTextField(5);
		t5.setFont(f1);
		t5.setForeground(Color.black);
	
		l7=new JLabel("6:\tADDRESS (PERM)");
		l7.setFont(f1);
		l7.setForeground(Color.black);

		t6=new JTextField(5);
		t6.setFont(f1);
		t6.setForeground(Color.black);

		l8=new JLabel("7:\tPHONE NO.(Mob)");
		l8.setFont(f1);
		l8.setForeground(Color.black);

		t7=new JTextField(5);
		t7.setFont(f1);
		t7.setForeground(Color.black);

		l9=new JLabel("8:\tPHONE NO.(Res)");
		l9.setFont(f1);
		l9.setForeground(Color.black);

		t8=new JTextField(5);
		t8.setFont(f1);
		t8.setForeground(Color.black);

		l10=new JLabel("10:\tCOLOUR");
		l10.setFont(f1);
		l10.setForeground(Color.black);

		t9=new JTextField(5);
		t9.setFont(f1);
		t9.setForeground(Color.black);

		l11=new JLabel("9:\tCAR");
		l11.setFont(f1);
		l11.setForeground(Color.black);

		t10=new JTextField(5);
		t10.setFont(f1);
		t10.setForeground(Color.black);

		l12=new JLabel("12:\tDATE OF PURCHASE");
		l12.setFont(f1);
		l12.setForeground(Color.black);
	
		t11=new JTextField(5);
		t11.setFont(f1);
		t11.setForeground(Color.black);

		l13=new JLabel("11:\tWHEELS");
		l13.setFont(f1);
		l13.setForeground(Color.black);
	
		t12=new JTextField(5);
		t12.setFont(f1);
		t12.setForeground(Color.black);
	
		b1=new JButton("CLEAR");
		b1.setFont(f1);
		b1.addActionListener(this);

		b2=new JButton("HOME");
		b2.setFont(f1);
		b2.addActionListener(this);

		b4=new JButton("DELETE");
		b4.setFont(f1);
		b4.addActionListener(this);

		b5=new JButton("SHOW");
		b5.setFont(f1);
		b5.addActionListener(this);

		p1=new JPanel();
		p1.setLayout(new FlowLayout());
		p1.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p2=new JPanel();
		p2.setLayout(new GridLayout(12,2));
		p2.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p3=new JPanel();
		p3.setLayout(new FlowLayout());
		p3.setBorder(new LineBorder(new Color(198,100,100),4,true));

		p1.add(l1);
		p1.add(addrs);
		p1.add(phlabel);

		p2.add(l2);		
		p2.add(t1); 

		p2.add(l3);		
		p2.add(t2);

		p2.add(l4);
		p2.add(t3);

		p2.add(l5);		
		p2.add(t4);

		p2.add(l6);		
		p2.add(t5);

		p2.add(l7);
		p2.add(t6);

		p2.add(l8);
		p2.add(t7);

		p2.add(l9);
		p2.add(t8);

		p2.add(l11);
		p2.add(t9);

		p2.add(l10);
		p2.add(t10);

		p2.add(l13);
		p2.add(t11);

		p2.add(l12);
		p2.add(t12);
		
		p3.add(b1);
		p3.add(b2);
		
		p3.add(b4);
		p3.add(b5);
		
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p2,BorderLayout.CENTER);
		cp.add(p3,BorderLayout.SOUTH);
	
		setBounds(130,100,800,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void do_update()
	{
		Connection con;
		try 
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:tybsc1");
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from custinfo");
			while(rs.next())
			{
				updateenqno = rs.getInt(1);				
			}
			updateenqno = updateenqno +1;
		}
		catch (SQLException se) 
		{
			System.out.println ("Ex1:"+se);
		}
		catch (Exception eg) 
		{
			System.out.println ("Ex2:"+eg);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str = ae.getActionCommand();
		Connection con ;
		Statement stat ;
		if(ae.getSource()==b1)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			t8.setText("");
			t9.setText(null);
			t10.setText(null);
			t11.setText(null);
			t12.setText(null);
		}
		if(ae.getSource()==b2)
		{
			dispose();
		 	homepage hp=new homepage();
		}
		if(ae.getSource()==b5)
		{
			String custid = JOptionPane.showInputDialog("Enter the Customer Number : ");
			if(custid==null)
			{
				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
			else
			{                
				try 
				{
					int cust=Integer.parseInt(custid);
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					System.out.println ("Got Connection :"+con);
					stat = con.createStatement();
					ResultSet rs = stat.executeQuery("select * from custinfo where custno="+cust);
					while(rs.next())
					{
						t1.setEditable(false);
						t2.setEditable(false);
						t3.setEditable(false);
						t4.setEditable(false);
						t5.setEditable(false);
						t6.setEditable(false);
						t7.setEditable(false);
						t8.setEditable(false);
						t9.setEditable(false);
						t10.setEditable(false);
						t11.setEditable(false);
						t12.setEditable(false);
						t1.setText(rs.getString(1));
						t2.setText(rs.getString(2));
						t3.setText(rs.getString(3));		    		
						t4.setText(rs.getString(4));			    		
						t5.setText(rs.getString(5));			    		
						t6.setText(rs.getString(6));
						t7.setText(rs.getString(7));
						t8.setText(rs.getString(8));    		
						t9.setText(rs.getString(9));			    		
						t10.setText(rs.getString(10));
						t11.setText(rs.getString(11));
						t12.setText(rs.getString(12));    		
					}
					con.close();
					stat.close();			    
				}	
				catch (SQLException e7) 
				{
					JOptionPane.showMessageDialog(null,"Record Not Found","Error",JOptionPane.ERROR_MESSAGE);
					t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.setText(null);
					t6.setText(null);
					t7.setText(null);
					t8.setText(null);
					t9.setText(null);
					t10.setText(null);
					t11.setText(null);
					t12.setText(null);
				}
				catch (Exception ex5) 
				{}
			}	
		}
		if(ae.getSource()==b4)
		{
			if(t1.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please enter the customer number","Error",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				int r=JOptionPane.showConfirmDialog(null,"Do You Want To Delete Record ?","THANK YOU",JOptionPane.YES_NO_OPTION);
				if(r==JOptionPane.YES_OPTION)
				try 
				{
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					con = DriverManager.getConnection("jdbc:odbc:tybsc1");
					System.out.println ("In delete Got Connection:"+con);
					Statement stmt3 = con.createStatement(); 
					stmt3.executeQuery("delete from custinfo where custno = "+Integer.parseInt(t1.getText()));
					stmt3.close();
					con.close();
				}
				catch (SQLException e8)
				{
					JOptionPane.showMessageDialog(null,"Record Deleted Successfully");
					t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.setText(null);
					t6.setText(null);
					t7.setText(null);
					t8.setText(null);
					t9.setText(null);
					t10.setText(null);
					t11.setText(null);
					t12.setText(null);
				}
				catch(Exception ex8)
				{
					JOptionPane.showMessageDialog(null,"Record Not Found");
				}
			}
		}
	}
	public static void main(String args[])
	{
		new cust_sale_info();
	}
}